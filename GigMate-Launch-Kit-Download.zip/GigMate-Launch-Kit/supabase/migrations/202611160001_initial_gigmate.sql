-- GigMate initial backend: real accounts, profiles, community gig submissions,
-- artist/venue directory, saved gigs, friend requests and crew planning.
-- Run with `supabase db push` or paste into the Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username = lower(username) and username ~ '^[a-z0-9_]{3,24}$'),
  display_name text not null default 'GigMate member',
  bio text not null default '',
  suburb text not null default '',
  state text not null default '',
  avatar_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('admin', 'moderator')),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

create or replace function public.is_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role in ('admin', 'moderator')
  );
$$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  base_name text;
begin
  base_name := lower(regexp_replace(
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'username'), ''), split_part(coalesce(new.email, 'fan'), '@', 1), 'fan'),
    '[^a-z0-9_]+', '_', 'g'
  ));
  base_name := trim(both '_' from base_name);
  if length(base_name) < 3 then base_name := 'fan'; end if;
  base_name := left(base_name, 24);

  -- Keep the username the member asked for when it is available. Add a suffix only on collision.
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    base_name,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''), 'GigMate member')
  )
  on conflict (username) do nothing;
  if not found then
    insert into public.profiles (id, username, display_name)
    values (
      new.id,
      left(base_name, 15) || '_' || substr(replace(new.id::text, '-', ''), 1, 8),
      coalesce(nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''), 'GigMate member')
    );
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_gigmate on auth.users;
create trigger on_auth_user_created_gigmate
after insert on auth.users
for each row execute function public.handle_new_user();

create table if not exists public.venues (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  suburb text not null,
  state text not null,
  country text not null default 'Australia',
  address text,
  website_url text,
  description text not null default '',
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'removed')),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create unique index if not exists venues_name_location_unique
  on public.venues (lower(name), lower(suburb), lower(state));
create index if not exists venues_status_location_idx on public.venues(status, state, suburb);

create table if not exists public.artists (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  bio text not null default '',
  genres text[] not null default '{}',
  home_suburb text not null default '',
  home_state text not null default '',
  website_url text,
  image_path text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'removed')),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create unique index if not exists artists_name_unique on public.artists (lower(name));
create index if not exists artists_status_name_idx on public.artists(status, name);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 4 and 140),
  description text not null default '',
  starts_at timestamptz not null,
  ends_at timestamptz,
  venue_id uuid references public.venues(id) on delete set null,
  venue_name text not null,
  suburb text not null,
  state text not null,
  country text not null default 'Australia',
  is_free boolean not null default false,
  price_from numeric(10,2),
  currency text not null default 'AUD',
  ticket_url text,
  age_restriction text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'cancelled', 'removed')),
  source_type text not null default 'community' check (source_type in ('community', 'artist', 'venue', 'promoter', 'api')),
  external_source text,
  external_id text,
  created_by uuid references auth.users(id) on delete set null,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (external_source, external_id)
);
create index if not exists events_public_upcoming_idx on public.events(status, starts_at);
create index if not exists events_location_idx on public.events(state, suburb, starts_at);
create index if not exists events_created_by_idx on public.events(created_by, created_at desc);
drop trigger if exists events_set_updated_at on public.events;
create trigger events_set_updated_at before update on public.events
for each row execute function public.set_updated_at();

create table if not exists public.event_lineup (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  artist_id uuid references public.artists(id) on delete set null,
  artist_name text not null,
  position integer not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists event_lineup_event_idx on public.event_lineup(event_id, position);

-- A gig submitted by a logged-in user is kept pending until a moderator approves it.
-- New venue/artist records are created as pending and are approved with their first approved event.
create or replace function public.submit_gig(
  p_title text,
  p_description text,
  p_starts_at timestamptz,
  p_venue_name text,
  p_suburb text,
  p_state text,
  p_lineup text[] default '{}',
  p_is_free boolean default false,
  p_price_from numeric default null,
  p_ticket_url text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_venue_id uuid;
  v_event_id uuid;
  v_artist_name text;
  v_artist_id uuid;
  v_position integer := 0;
begin
  if v_user is null then raise exception 'Sign in before submitting a gig.'; end if;
  if p_title is null or char_length(trim(p_title)) < 4 or char_length(trim(p_title)) > 140 then
    raise exception 'Gig title must be between 4 and 140 characters.';
  end if;
  if p_starts_at is null or p_starts_at < now() then
    raise exception 'Choose a valid upcoming gig date and time.';
  end if;
  if p_description is not null and char_length(p_description) > 2000 then raise exception 'Description must be 2,000 characters or fewer.'; end if;
  if coalesce(cardinality(p_lineup), 0) > 30 then raise exception 'A gig can list up to 30 artists.'; end if;
  if p_venue_name is null or char_length(trim(p_venue_name)) not between 2 and 120 then raise exception 'Enter a venue name between 2 and 120 characters.'; end if;
  if p_suburb is null or char_length(trim(p_suburb)) not between 2 and 100 then raise exception 'Enter a suburb or town between 2 and 100 characters.'; end if;
  if p_state is null or char_length(trim(p_state)) not between 2 and 3 then raise exception 'Enter a state or territory abbreviation.'; end if;
  if (select count(*) from public.events where created_by = v_user and created_at > now() - interval '24 hours') >= 10 then
    raise exception 'You can submit up to 10 gigs in a 24-hour period.';
  end if;
  if p_price_from is not null and p_price_from < 0 then raise exception 'Ticket price cannot be negative.'; end if;
  if p_ticket_url is not null and trim(p_ticket_url) <> '' and p_ticket_url !~* '^https?://' then
    raise exception 'Ticket link must start with http:// or https://.';
  end if;

  select id into v_venue_id from public.venues
    where lower(name) = lower(trim(p_venue_name))
      and lower(suburb) = lower(trim(p_suburb))
      and lower(state) = lower(trim(p_state))
    limit 1;

  if v_venue_id is null then
    insert into public.venues(name, suburb, state, created_by, status)
    values(trim(p_venue_name), trim(p_suburb), trim(p_state), v_user, 'pending')
    on conflict do nothing
    returning id into v_venue_id;
    if v_venue_id is null then
      select id into v_venue_id from public.venues
        where lower(name) = lower(trim(p_venue_name))
          and lower(suburb) = lower(trim(p_suburb))
          and lower(state) = lower(trim(p_state)) limit 1;
    end if;
  end if;

  insert into public.events(
    title, description, starts_at, venue_id, venue_name, suburb, state,
    is_free, price_from, ticket_url, status, source_type, created_by
  ) values (
    trim(p_title), coalesce(p_description, ''), p_starts_at, v_venue_id,
    trim(p_venue_name), trim(p_suburb), trim(p_state), coalesce(p_is_free, false),
    p_price_from, nullif(trim(coalesce(p_ticket_url, '')), ''), 'pending', 'community', v_user
  ) returning id into v_event_id;

  foreach v_artist_name in array coalesce(p_lineup, '{}') loop
    v_artist_name := trim(v_artist_name);
    if char_length(v_artist_name) >= 2 and char_length(v_artist_name) <= 100 then
      select id into v_artist_id from public.artists where lower(name) = lower(v_artist_name) limit 1;
      if v_artist_id is null then
        insert into public.artists(name, home_suburb, home_state, created_by, status)
        values(v_artist_name, trim(p_suburb), trim(p_state), v_user, 'pending')
        on conflict do nothing returning id into v_artist_id;
        if v_artist_id is null then
          select id into v_artist_id from public.artists where lower(name) = lower(v_artist_name) limit 1;
        end if;
      end if;
      insert into public.event_lineup(event_id, artist_id, artist_name, position)
      values(v_event_id, v_artist_id, v_artist_name, v_position);
      v_position := v_position + 1;
      v_artist_id := null;
    end if;
  end loop;
  return v_event_id;
end;
$$;

-- Approving an event also approves its associated directory records after moderation.
create or replace function public.approve_event_directory_records()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.status = 'approved' and old.status is distinct from 'approved' then
    if new.venue_id is not null then update public.venues set status = 'approved' where id = new.venue_id and status = 'pending'; end if;
    update public.artists a set status = 'approved'
      where a.id in (select artist_id from public.event_lineup where event_id = new.id and artist_id is not null)
        and a.status = 'pending';
  end if;
  return new;
end;
$$;
drop trigger if exists approve_event_directory_records_trigger on public.events;
create trigger approve_event_directory_records_trigger
  after update of status on public.events
  for each row execute function public.approve_event_directory_records();

create table if not exists public.saved_events (
  user_id uuid not null references auth.users(id) on delete cascade,
  event_id uuid not null references public.events(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, event_id)
);

create table if not exists public.artist_follows (
  user_id uuid not null references auth.users(id) on delete cascade,
  artist_id uuid not null references public.artists(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, artist_id)
);
create table if not exists public.venue_follows (
  user_id uuid not null references auth.users(id) on delete cascade,
  venue_id uuid not null references public.venues(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, venue_id)
);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'declined', 'cancelled')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  check (sender_id <> recipient_id),
  unique (sender_id, recipient_id)
);
create index if not exists friend_requests_recipient_idx on public.friend_requests(recipient_id, status);

-- Blocking is a first-class safety control. Blocking either direction removes the friend request.
create table if not exists public.user_blocks (
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blockee_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blockee_id),
  check (blocker_id <> blockee_id)
);
create index if not exists user_blocks_blockee_idx on public.user_blocks(blockee_id, blocker_id);

create or replace function public.block_member(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'Sign in first.'; end if;
  if p_user_id is null or p_user_id = auth.uid() then raise exception 'Choose another GigMate member to block.'; end if;
  if not exists(select 1 from auth.users where id = p_user_id) then raise exception 'That member account could not be found.'; end if;
  insert into public.user_blocks(blocker_id, blockee_id) values(auth.uid(), p_user_id) on conflict do nothing;
  delete from public.friend_requests
    where (sender_id = auth.uid() and recipient_id = p_user_id)
       or (sender_id = p_user_id and recipient_id = auth.uid());
end;
$$;

create or replace function public.unblock_member(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'Sign in first.'; end if;
  delete from public.user_blocks where blocker_id = auth.uid() and blockee_id = p_user_id;
end;
$$;

create or replace function public.list_blocked_members()
returns table(id uuid, username text, display_name text)
language sql
stable
security definer
set search_path = public
as $$
  select p.id, p.username, p.display_name
  from public.user_blocks b
  join public.profiles p on p.id = b.blockee_id
  where b.blocker_id = auth.uid()
  order by p.username;
$$;

create or replace function public.send_friend_request(p_username text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_recipient uuid;
  v_existing uuid;
  v_existing_sender uuid;
  v_existing_status text;
begin
  if auth.uid() is null then raise exception 'Sign in first.'; end if;
  select id into v_recipient from public.profiles where lower(username) = lower(trim(p_username));
  if v_recipient is null then raise exception 'No GigMate member found with that username.'; end if;
  if v_recipient = auth.uid() then raise exception 'You cannot add yourself.'; end if;
  if exists(select 1 from public.user_blocks b where (b.blocker_id=auth.uid() and b.blockee_id=v_recipient) or (b.blocker_id=v_recipient and b.blockee_id=auth.uid())) then
    raise exception 'A friend request cannot be sent because one account has blocked the other.';
  end if;

  select id, sender_id, status into v_existing, v_existing_sender, v_existing_status
    from public.friend_requests
    where ((sender_id = auth.uid() and recipient_id = v_recipient)
        or (sender_id = v_recipient and recipient_id = auth.uid()))
      and status in ('pending','accepted')
    order by case when status = 'accepted' then 0 else 1 end
    limit 1;
  if v_existing is not null then
    if v_existing_status = 'pending' and v_existing_sender = v_recipient then
      update public.friend_requests set status = 'accepted', responded_at = now() where id = v_existing;
    end if;
    return v_existing;
  end if;

  insert into public.friend_requests(sender_id, recipient_id)
  values(auth.uid(), v_recipient)
  on conflict (sender_id, recipient_id) do update set status='pending', created_at=now(), responded_at=null
  returning id into v_existing;
  return v_existing;
end;
$$;

create or replace function public.respond_friend_request(p_request_id uuid, p_accept boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.friend_requests
  set status = case when p_accept then 'accepted' else 'declined' end,
      responded_at = now()
  where id = p_request_id and recipient_id = auth.uid() and status = 'pending';
  if not found then raise exception 'That friend request is no longer available.'; end if;
end;
$$;

create table if not exists public.crews (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 60),
  invite_code text not null unique,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.crew_members (
  crew_id uuid not null references public.crews(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','member')),
  joined_at timestamptz not null default now(),
  primary key (crew_id, user_id)
);

create or replace function public.is_crew_member(p_crew_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$ select exists(select 1 from public.crew_members where crew_id=p_crew_id and user_id=auth.uid()); $$;

create or replace function public.create_crew(p_name text)
returns table(id uuid, name text, invite_code text)
language plpgsql
security definer
set search_path = public
as $$
declare v_id uuid; v_code text;
begin
  if auth.uid() is null then raise exception 'Sign in first.'; end if;
  if p_name is null or char_length(trim(p_name)) not between 2 and 60 then raise exception 'Crew name must be 2–60 characters.'; end if;
  v_code := upper(substr(encode(gen_random_bytes(8), 'hex'), 1, 12));
  insert into public.crews(name, invite_code, created_by) values(trim(p_name), v_code, auth.uid()) returning crews.id into v_id;
  insert into public.crew_members(crew_id, user_id, role) values(v_id, auth.uid(), 'owner');
  return query select c.id, c.name, c.invite_code from public.crews c where c.id=v_id;
end;
$$;

create or replace function public.join_crew(p_invite_code text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare v_crew uuid;
begin
  if auth.uid() is null then raise exception 'Sign in first.'; end if;
  select id into v_crew from public.crews where invite_code=upper(trim(p_invite_code));
  if v_crew is null then raise exception 'That crew invite code was not found.'; end if;
  insert into public.crew_members(crew_id, user_id, role) values(v_crew, auth.uid(), 'member') on conflict do nothing;
  return v_crew;
end;
$$;

create table if not exists public.crew_event_votes (
  crew_id uuid not null references public.crews(id) on delete cascade,
  event_id uuid not null references public.events(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  vote text not null check (vote in ('going','maybe','not_going')),
  updated_at timestamptz not null default now(),
  primary key (crew_id, event_id, user_id)
);

-- Event reporting supports moderation and community corrections.
create table if not exists public.event_reports (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reason text not null check (char_length(reason) between 5 and 1000),
  status text not null default 'open' check (status in ('open','reviewed','dismissed')),
  created_at timestamptz not null default now(),
  unique (event_id, reporter_id)
);

-- Core tables: row-level security is mandatory. Public visitors can read only approved event data.
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.venues enable row level security;
alter table public.artists enable row level security;
alter table public.events enable row level security;
alter table public.event_lineup enable row level security;
alter table public.saved_events enable row level security;
alter table public.artist_follows enable row level security;
alter table public.venue_follows enable row level security;
alter table public.friend_requests enable row level security;
alter table public.user_blocks enable row level security;
alter table public.crews enable row level security;
alter table public.crew_members enable row level security;
alter table public.crew_event_votes enable row level security;
alter table public.event_reports enable row level security;

-- Profiles are visible to signed-in members; each member edits only their own profile.
drop policy if exists profiles_read_authenticated on public.profiles;
create policy profiles_read_authenticated on public.profiles for select to authenticated using (
  id = auth.uid() or not exists (
    select 1 from public.user_blocks b
    where (b.blocker_id = auth.uid() and b.blockee_id = id)
       or (b.blocker_id = id and b.blockee_id = auth.uid())
  )
);
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

drop policy if exists user_roles_read_self_or_staff on public.user_roles;
create policy user_roles_read_self_or_staff on public.user_roles for select to authenticated using (user_id=auth.uid() or public.is_staff());

-- Direct public writes to venues/artists/events are not allowed; submissions use the validated RPC above.
drop policy if exists venues_read_approved_or_owner on public.venues;
create policy venues_read_approved_or_owner on public.venues for select to anon, authenticated using (
  (status='approved' or created_by=auth.uid() or public.is_staff())
  and not exists (
    select 1 from public.user_blocks b
    where (b.blocker_id=auth.uid() and b.blockee_id=venues.created_by)
       or (b.blocker_id=venues.created_by and b.blockee_id=auth.uid())
  )
);
drop policy if exists artists_read_approved_or_owner on public.artists;
create policy artists_read_approved_or_owner on public.artists for select to anon, authenticated using (
  (status='approved' or created_by=auth.uid() or public.is_staff())
  and not exists (
    select 1 from public.user_blocks b
    where (b.blocker_id=auth.uid() and b.blockee_id=artists.created_by)
       or (b.blocker_id=artists.created_by and b.blockee_id=auth.uid())
  )
);
drop policy if exists events_read_approved_or_owner on public.events;
create policy events_read_approved_or_owner on public.events for select to anon, authenticated using (
  (status='approved' or created_by=auth.uid() or public.is_staff())
  and not exists (
    select 1 from public.user_blocks b
    where (b.blocker_id = auth.uid() and b.blockee_id = events.created_by)
       or (b.blocker_id = events.created_by and b.blockee_id = auth.uid())
  )
);
drop policy if exists events_staff_update on public.events;
create policy events_staff_update on public.events for update to authenticated using (public.is_staff()) with check (public.is_staff());
drop policy if exists lineup_read_visible_event on public.event_lineup;
create policy lineup_read_visible_event on public.event_lineup for select to anon, authenticated using (
  exists(
    select 1 from public.events e
    where e.id=event_id
      and (e.status='approved' or e.created_by=auth.uid() or public.is_staff())
      and not exists (
        select 1 from public.user_blocks b
        where (b.blocker_id=auth.uid() and b.blockee_id=e.created_by)
           or (b.blocker_id=e.created_by and b.blockee_id=auth.uid())
      )
  )
);

-- Saved items and follows belong to the signed-in member.
drop policy if exists saved_events_self_all on public.saved_events;
create policy saved_events_self_all on public.saved_events for all to authenticated
  using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists artist_follows_self_all on public.artist_follows;
create policy artist_follows_self_all on public.artist_follows for all to authenticated
  using (user_id=auth.uid()) with check (user_id=auth.uid());
drop policy if exists venue_follows_self_all on public.venue_follows;
create policy venue_follows_self_all on public.venue_follows for all to authenticated
  using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Friend request rows are visible only to the two members involved. Changes use secure RPCs.
drop policy if exists friend_requests_read_participants on public.friend_requests;
create policy friend_requests_read_participants on public.friend_requests for select to authenticated
  using (sender_id=auth.uid() or recipient_id=auth.uid());

drop policy if exists user_blocks_read_participants on public.user_blocks;
create policy user_blocks_read_participants on public.user_blocks for select to authenticated
  using (blocker_id=auth.uid() or blockee_id=auth.uid());
drop policy if exists user_blocks_insert_self on public.user_blocks;
create policy user_blocks_insert_self on public.user_blocks for insert to authenticated
  with check (blocker_id=auth.uid() and blockee_id<>auth.uid());
drop policy if exists user_blocks_delete_self on public.user_blocks;
create policy user_blocks_delete_self on public.user_blocks for delete to authenticated
  using (blocker_id=auth.uid());

-- Crew information is available only to members. Invite code operations use server-side RPCs.
drop policy if exists crews_read_members on public.crews;
create policy crews_read_members on public.crews for select to authenticated using (public.is_crew_member(id));
drop policy if exists crew_members_read_members on public.crew_members;
create policy crew_members_read_members on public.crew_members for select to authenticated using (public.is_crew_member(crew_id));
drop policy if exists crew_votes_read_members on public.crew_event_votes;
create policy crew_votes_read_members on public.crew_event_votes for select to authenticated using (public.is_crew_member(crew_id));
drop policy if exists crew_votes_insert_self on public.crew_event_votes;
create policy crew_votes_insert_self on public.crew_event_votes for insert to authenticated
  with check (user_id=auth.uid() and public.is_crew_member(crew_id));
drop policy if exists crew_votes_update_self on public.crew_event_votes;
create policy crew_votes_update_self on public.crew_event_votes for update to authenticated
  using (user_id=auth.uid() and public.is_crew_member(crew_id))
  with check (user_id=auth.uid() and public.is_crew_member(crew_id));
drop policy if exists crew_votes_delete_self on public.crew_event_votes;
create policy crew_votes_delete_self on public.crew_event_votes for delete to authenticated
  using (user_id=auth.uid() and public.is_crew_member(crew_id));

-- A member can report an approved event once. Only staff can review reports.
drop policy if exists event_reports_insert_self on public.event_reports;
create policy event_reports_insert_self on public.event_reports for insert to authenticated
  with check (reporter_id=auth.uid() and exists(select 1 from public.events e where e.id=event_id and e.status='approved'));
drop policy if exists event_reports_read_self_or_staff on public.event_reports;
create policy event_reports_read_self_or_staff on public.event_reports for select to authenticated
  using (reporter_id=auth.uid() or public.is_staff());
drop policy if exists event_reports_staff_update on public.event_reports;
create policy event_reports_staff_update on public.event_reports for update to authenticated
  using (public.is_staff()) with check (public.is_staff());

-- Remove any broad default table privileges before granting only the required operations.
revoke all on public.profiles, public.user_roles, public.venues, public.artists,
  public.events, public.event_lineup, public.saved_events, public.artist_follows,
  public.venue_follows, public.friend_requests, public.user_blocks, public.crews, public.crew_members,
  public.crew_event_votes, public.event_reports from anon, authenticated;

-- Security-definer functions are executable only by the intended roles.
revoke all on function public.handle_new_user() from public, anon, authenticated;
revoke all on function public.set_updated_at() from public, anon, authenticated;
revoke all on function public.approve_event_directory_records() from public, anon, authenticated;
revoke all on function public.submit_gig(text,text,timestamptz,text,text,text,text[],boolean,numeric,text) from public, anon, authenticated;
revoke all on function public.send_friend_request(text) from public, anon, authenticated;
revoke all on function public.respond_friend_request(uuid,boolean) from public, anon, authenticated;
revoke all on function public.block_member(uuid) from public, anon, authenticated;
revoke all on function public.unblock_member(uuid) from public, anon, authenticated;
revoke all on function public.list_blocked_members() from public, anon, authenticated;
revoke all on function public.create_crew(text) from public, anon, authenticated;
revoke all on function public.join_crew(text) from public, anon, authenticated;
revoke all on function public.is_staff() from public, anon, authenticated;
revoke all on function public.is_crew_member(uuid) from public, anon, authenticated;

-- Restrict table privileges in addition to RLS. SECURITY DEFINER RPCs perform validated writes.
revoke all on public.user_roles from anon, authenticated;
grant select on public.user_roles to authenticated;
grant select on public.user_blocks to anon, authenticated;
grant insert, delete on public.user_blocks to authenticated;
revoke insert, update, delete on public.venues, public.artists, public.events, public.event_lineup from anon, authenticated;
grant select on public.venues, public.artists, public.events, public.event_lineup to anon, authenticated;
grant update on public.events to authenticated;
grant select on public.profiles to authenticated;
grant update (username, display_name, bio, suburb, state, avatar_path, updated_at) on public.profiles to authenticated;
grant select, insert, delete on public.saved_events, public.artist_follows, public.venue_follows to authenticated;
grant select on public.friend_requests to authenticated;
grant select on public.crews, public.crew_members, public.crew_event_votes to authenticated;
grant insert, update, delete on public.crew_event_votes to authenticated;
grant select, insert on public.event_reports to authenticated;
grant update on public.event_reports to authenticated;

grant execute on function public.submit_gig(text,text,timestamptz,text,text,text,text[],boolean,numeric,text) to authenticated;
grant execute on function public.send_friend_request(text) to authenticated;
grant execute on function public.respond_friend_request(uuid,boolean) to authenticated;
grant execute on function public.block_member(uuid) to authenticated;
grant execute on function public.unblock_member(uuid) to authenticated;
grant execute on function public.list_blocked_members() to authenticated;
grant execute on function public.create_crew(text) to authenticated;
grant execute on function public.join_crew(text) to authenticated;
grant execute on function public.is_staff() to anon, authenticated;
grant execute on function public.is_crew_member(uuid) to authenticated;

-- Avatar storage: public read, private write paths scoped to the signed-in user's UUID.
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
drop policy if exists avatars_public_read on storage.objects;
create policy avatars_public_read on storage.objects for select to anon, authenticated using (bucket_id='avatars');
drop policy if exists avatars_owner_insert on storage.objects;
create policy avatars_owner_insert on storage.objects for insert to authenticated
  with check (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists avatars_owner_update on storage.objects;
create policy avatars_owner_update on storage.objects for update to authenticated
  using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text)
  with check (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists avatars_owner_delete on storage.objects;
create policy avatars_owner_delete on storage.objects for delete to authenticated
  using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);

-- Admin bootstrap: after registering your own GigMate account, run this once in the
-- Supabase SQL Editor, replacing the email with the account you own:
-- insert into public.user_roles(user_id, role)
-- select id, 'admin' from auth.users where lower(email)=lower('YOUR_EMAIL_ADDRESS')
-- on conflict do nothing;
