import { createClient } from 'npm:@supabase/supabase-js@2'

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers })
  if (request.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405, headers })

  const authorization = request.headers.get('Authorization')
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  const supabaseUrl = Deno.env.get('SUPABASE_URL')
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')
  if (!authorization || !serviceRoleKey || !supabaseUrl || !anonKey) {
    return Response.json({ error: 'Account deletion is not configured on this backend.' }, { status: 503, headers })
  }

  const userClient = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authorization } } })
  const { data: userData, error: authError } = await userClient.auth.getUser()
  if (authError || !userData.user) return Response.json({ error: 'Sign in again before deleting your account.' }, { status: 401, headers })

  const adminClient = createClient(supabaseUrl, serviceRoleKey, { auth: { autoRefreshToken: false, persistSession: false } })
  const { data: profile } = await adminClient.from('profiles').select('avatar_path').eq('id', userData.user.id).maybeSingle()
  if (profile?.avatar_path) {
    const { error: storageError } = await adminClient.storage.from('avatars').remove([profile.avatar_path])
    if (storageError) console.error('Avatar cleanup failed during account deletion:', storageError.message)
  }

  // Delete events and directory records submitted by this account. Linked lineup,
  // saved-event and report rows cascade; artist/venue references on other members'
  // events are set null while their public display names remain as event text.
  const { error: eventsError } = await adminClient.from('events').delete().eq('created_by', userData.user.id)
  if (eventsError) {
    console.error('Gig cleanup failed during account deletion:', eventsError.message)
    return Response.json({ error: 'Your submitted gigs could not be removed. Please contact GigMate support before retrying.' }, { status: 500, headers })
  }
  const { error: artistsError } = await adminClient.from('artists').delete().eq('created_by', userData.user.id)
  if (artistsError) {
    console.error('Artist cleanup failed during account deletion:', artistsError.message)
    return Response.json({ error: 'Your artist directory records could not be removed. Please contact GigMate support before retrying.' }, { status: 500, headers })
  }
  const { error: venuesError } = await adminClient.from('venues').delete().eq('created_by', userData.user.id)
  if (venuesError) {
    console.error('Venue cleanup failed during account deletion:', venuesError.message)
    return Response.json({ error: 'Your venue directory records could not be removed. Please contact GigMate support before retrying.' }, { status: 500, headers })
  }

  const { error: deleteError } = await adminClient.auth.admin.deleteUser(userData.user.id)
  if (deleteError) {
    console.error('Account deletion failed:', deleteError.message)
    return Response.json({ error: 'Your account could not be deleted. Please contact GigMate support.' }, { status: 500, headers })
  }

  return Response.json({ success: true }, { headers })
})
