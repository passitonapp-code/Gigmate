import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (request.method !== 'POST') return Response.json({ error: 'Method not allowed' }, { status: 405, headers: corsHeaders })

  const apiKey = Deno.env.get('TICKETMASTER_API_KEY')
  if (!apiKey) {
    return Response.json(
      { error: 'Ticketmaster search has not been configured. Add TICKETMASTER_API_KEY to Supabase Edge Function secrets before enabling this feature.' },
      { status: 503, headers: corsHeaders },
    )
  }

  const authHeader = request.headers.get('Authorization')
  if (!authHeader) return Response.json({ error: 'Sign in is required.' }, { status: 401, headers: corsHeaders })

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!
  const supabase = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } })
  const { data: userData, error: userError } = await supabase.auth.getUser()
  if (userError || !userData.user) return Response.json({ error: 'Your session could not be verified.' }, { status: 401, headers: corsHeaders })

  let payload: { keyword?: string; city?: string; stateCode?: string }
  try { payload = await request.json() } catch { return Response.json({ error: 'Invalid JSON body.' }, { status: 400, headers: corsHeaders }) }

  const keyword = (payload.keyword ?? '').trim().slice(0, 100)
  const city = (payload.city ?? '').trim().slice(0, 80)
  const stateCode = (payload.stateCode ?? '').trim().slice(0, 3).toUpperCase()
  if (!keyword && !city) return Response.json({ error: 'Enter an artist, gig keyword or city.' }, { status: 400, headers: corsHeaders })

  const url = new URL('https://app.ticketmaster.com/discovery/v2/events.json')
  url.searchParams.set('apikey', apiKey)
  url.searchParams.set('countryCode', 'AU')
  url.searchParams.set('classificationName', 'music')
  url.searchParams.set('size', '30')
  url.searchParams.set('sort', 'date,asc')
  if (keyword) url.searchParams.set('keyword', keyword)
  if (city) url.searchParams.set('city', city)
  if (stateCode) url.searchParams.set('stateCode', stateCode)

  const upstream = await fetch(url, { headers: { Accept: 'application/json' } })
  if (!upstream.ok) {
    const details = await upstream.text()
    console.error('Ticketmaster request failed:', upstream.status, details.slice(0, 500))
    return Response.json({ error: 'The external event provider did not return a successful response.' }, { status: 502, headers: corsHeaders })
  }

  const body = await upstream.json()
  const events = (body?._embedded?.events ?? []).map((event: any) => {
    const venue = event?._embedded?.venues?.[0]
    const attractionNames = event?._embedded?.attractions?.map((item: any) => item.name).filter(Boolean) ?? []
    return {
      id: String(event.id),
      name: String(event.name ?? 'Untitled event'),
      startsAt: event?.dates?.start?.dateTime ?? event?.dates?.start?.localDate ?? null,
      venue: venue?.name ?? 'Venue TBA',
      city: venue?.city?.name ?? '',
      state: venue?.state?.stateCode ?? '',
      artists: attractionNames,
      url: event?.url ?? null,
      source: 'Ticketmaster',
    }
  })

  return Response.json({ events, source: 'Ticketmaster', attributionUrl: 'https://www.ticketmaster.com/' }, { headers: corsHeaders })
})
