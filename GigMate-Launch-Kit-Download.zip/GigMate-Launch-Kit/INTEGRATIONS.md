# External integrations and local gig coverage

## Grassroots-first listings

GigMate's core event source is direct participation from the local scene:

- Artists/bands and their managers submit shows and line-ups.
- Venues publish calendars and weekly line-ups.
- Promoters submit multi-act bills and support slots.
- Fans submit a show discovered from a poster, venue noticeboard or word of mouth.
- Moderators review submissions, reject spam and resolve duplicate/corrected listings.

This is the only reliable route to shows that are never entered into large ticketing databases. Make submissions fast on mobile, allow multiple acts/set times, let venue accounts claim their pages, and support free-entry / door-sales events. Keep a visible review state and a report action.

## Ticketmaster Discovery API (optional adapter included)

The `search-ticketmaster` Supabase Edge Function calls the official Discovery API from the server. The API key is stored as a Supabase Function Secret. Its results are clearly labelled Ticketmaster and link to the official event page. It supplements local community listings and is not imported as a community-verified gig.

The Discovery API can search events, attractions and venues, but broad ticketing feeds have limited coverage of independent pub gigs and free community events.

## Bandsintown

Do not scrape Bandsintown or reuse an artist-specific API key as a platform-wide key. Bandsintown says its API is intended for artists and their teams displaying their own shows; platform companies seeking multi-artist access must submit an API access request. Access is read-only and platform integrations must follow attribution and call-to-action requirements. Apply for approval before implementing a cross-artist data import.

## Spotify

Spotify is not included in the launch path. GigMate does not need a Spotify connection to deliver local gig discovery, and music-listening data introduces extra consent, policy and developer-access requirements. Build artist follows and favourite genres inside GigMate first.

## Never do

- Scrape private social media pages or bypass access controls.
- Import third-party event data without the provider's permission/licence and required attribution.
- Treat a Ticketmaster / Bandsintown feed as the complete local music scene.
- Publish unreviewed community submissions as verified events.
- Fabricate API success when credentials are missing.
