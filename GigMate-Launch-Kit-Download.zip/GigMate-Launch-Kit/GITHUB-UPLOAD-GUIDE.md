# Put the GigMate launch kit into GitHub (including from Android)

Do not replace `main` directly. Work on a new branch so the live prototype stays available until the replacement passes checks.

## Recommended: computer or GitHub Codespaces

1. Download and extract `GigMate-Launch-Kit.zip`.
2. In `passitonapp-code/Gigmate`, create a new branch from `main` named `feature/real-gigmate-app`.
3. Upload the **contents** of the extracted `GigMate-Launch-Kit` folder into the repository root on that branch. Do not put the entire project inside an extra nested folder.
4. Allow the upload to replace the old `index.html` and `README.md`.
5. Remove the old root-level `manifest.webmanifest`, `service-worker.js`, and `icon.svg`. The Vite app uses the replacement assets in `public/`.
6. Commit the changes to the feature branch and open a pull request into `main`.
7. Wait for the GitHub Actions build check. Do not merge if it fails.
8. Connect Vercel/Netlify to the repository and test the pull-request preview with the Supabase backend. Do not merge yet: the old GitHub Pages host cannot serve the new Vite source files directly.
9. Once the preview, sign-in, gig submission, moderation and social flows work, merge the PR and let Vercel/Netlify publish the new production build. The old GitHub Pages URL should no longer be treated as the production app.

## Phone route when GitHub cannot upload a folder

The GitHub mobile upload picker may not preserve a folder tree. One way around that is to upload the ZIP first, then unpack it in a Codespace:

1. In the repository, create branch `feature/real-gigmate-app` from `main`.
2. Upload `GigMate-Launch-Kit.zip` to that branch and commit it.
3. Open the repository's **Code** menu, select **Codespaces**, and create a Codespace on `feature/real-gigmate-app` (if Codespaces is available for your GitHub account).
4. In the Codespace terminal, run:

   ```bash
   unzip GigMate-Launch-Kit.zip -d /tmp/gigmate-kit
   cp -a /tmp/gigmate-kit/GigMate-Launch-Kit/. .
   rm -f GigMate-Launch-Kit.zip
   rm -f manifest.webmanifest service-worker.js icon.svg
   git add -A
   git commit -m "Replace static prototype with GigMate app foundation"
   git push
   ```

5. Return to GitHub and open a pull request from `feature/real-gigmate-app` into `main`.

If Codespaces is unavailable, use a computer to upload the extracted folder, or use a Git GUI that can commit a directory tree. Do not try to paste the whole project into the single-file GitHub editor.

## Vercel/Netlify preview and production

Import the repository in Vercel/Netlify and enable pull-request preview deployments. Set build command `npm run build`, output directory `dist`, and add `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` to Preview and Production environments. Add the preview/production URLs to Supabase Auth's allowed redirect URLs. Test the preview first, then merge the PR; the provider will publish the main branch as production. GitHub Pages cannot compile Vite's TypeScript source on its own, so do not rely on the previous GitHub Pages deployment after the replacement is merged. Keep Supabase secrets out of GitHub and out of all `VITE_` variables.
