import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'au.com.gigmate.app',
  appName: 'GigMate',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
}

export default config
