# GigMate ticket resale marketplace — activation gate

## Current status

**Ticket resale is deliberately absent from the live interface and is not enabled by this codebase.** No Buy, Sell, payment, escrow, payout or ticket-transfer button is shown. This is intentional: a production marketplace cannot be made trustworthy by adding a checkout screen alone.

## The Tixel-style flow we intend to implement

1. Seller completes identity and payout onboarding with the approved marketplace payment provider.
2. Seller uploads ticket evidence into private, access-controlled storage.
3. The service extracts event, ticket type and original price data, then runs duplicate/fraud checks and manual review where required.
4. Listing is published only for a supported ticket provider and transfer type.
5. Buyer sees the primary-sale price, resale amount, all GigMate fees and the transfer/refund conditions before paying.
6. The backend creates a marketplace payment / split transaction with the approved provider.
7. The ticket is transferred using the original ticket provider's supported transfer mechanism, or an approved reissue process.
8. Server-to-server webhooks update payment and transfer states. Seller funds are paid out only under the contractually approved provider workflow.
9. Refunds, disputes, event cancellation, chargebacks, failed transfers and suspected fraud have explicit support and audit processes.

A screenshot, PDF or static QR scan is not proof that a ticket is unused, valid or transferable. Some mobile tickets use rotating or account-bound codes. The marketplace must not accept ticket types it cannot reliably transfer or verify.

## Payment provider

Adyen for Platforms is the initial provider to approach because its platform offering supports seller onboarding, payments, balance accounts and payouts. Adyen's own onboarding process starts by contacting them, scoping the business model, receiving a test account, integrating and testing, then applying for a live account and configuring it. This kit does not contain production Adyen checkout/payout code or credentials because the API design depends on the contract and platform configuration Adyen supplies.

Do not assume Stripe Connect will approve the model. Obtain written approval from any payment provider for secondary ticket resale, seller payouts and the proposed control of funds before writing the live payment path.

## Required business decisions and partner approvals

- Australian business entity, ABN, bank account, beneficial-owner details and tax/accounting advice.
- Written approval from Adyen or another marketplace provider for peer-to-peer ticket resale.
- Primary ticket platforms whose tickets can be transferred or reissued (for example, Ticketek, Ticketmaster, Moshtix, Humanitix and Eventbrite); obtain each platform's current policy and partner process.
- A documented seller identity check, ticket evidence process, duplicate-ticket handling, transfer confirmation and dispute policy.
- Legal review for ticket resale/scalping rules in every launch state and territory.
- Event-specific resale cap data and enforcement rules. Do not hard-code a generic 10% rule for every Australian event.

## Queensland rule to account for

Queensland's Major Events Act 2014 section 31 prohibits offering a ticket to a Queensland major event above 10% over its original sale price, unless the event organiser has given written approval. The Act defines the original sale price to include the authorised sale price and fees/commissions. This rule is scoped to major events under that Act; other Queensland and interstate rules may apply to other event types. Store the event's legal resale rule and primary price evidence, and have Australian counsel review the model before launch.

## Do not activate until all are true

- The payment provider has approved the business model in writing and issued test/live platform credentials.
- Seller onboarding and payout account verification pass test cases.
- A ticket-transfer arrangement exists for each ticket type accepted.
- All platform webhooks are signature-verified and idempotent.
- Listing price limits, fees, disclosure text, tax receipts and seller records are reviewed.
- Refund, cancellation, chargeback and failed-transfer scenarios have been tested end-to-end.
- Marketplace screens only render for an event/provider where the flow is supported.

Until then GigMate can link to an event's official ticket page. It must not present a nonfunctional resale marketplace as available.
