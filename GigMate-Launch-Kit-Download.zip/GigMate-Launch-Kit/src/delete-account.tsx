import { useState, type FormEvent } from 'react'
import ReactDOM from 'react-dom/client'
import { createClient } from '@supabase/supabase-js'
import './styles.css'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY
const configured = Boolean(supabaseUrl && publishableKey && !supabaseUrl.includes('YOUR_PROJECT_REF') && !publishableKey.includes('YOUR_SUPABASE'))
const client = configured ? createClient(supabaseUrl!, publishableKey!, {
  auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
}) : null

function DeleteAccountPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [working, setWorking] = useState(false)
  const [message, setMessage] = useState('')
  const [success, setSuccess] = useState(false)

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!client) { setMessage('Account deletion is not configured on this site yet. Please use the published GigMate support contact.'); return }
    setWorking(true); setMessage('')
    const { error: signInError } = await client.auth.signInWithPassword({ email: email.trim(), password })
    if (signInError) { setWorking(false); setMessage('We could not verify those sign-in details. Check your email and password, then try again.'); return }
    const { data, error: deleteError } = await client.functions.invoke('delete-account', { body: {} })
    setWorking(false)
    if (deleteError || data?.error) { setMessage(deleteError?.message || data.error || 'Your deletion request could not be completed. Please contact GigMate support.'); return }
    setPassword('')
    setSuccess(true)
  }

  return <main className="legal-page">
    <a href="/">← Back to GigMate</a>
    <h1>Delete your GigMate account</h1>
    <p className="warning">This page lets you request deletion from a web browser, even if you have uninstalled the mobile app.</p>
    {success ? <section className="deletion-success" role="status"><h2>Account deletion completed</h2><p>Your GigMate account and associated account data have been deleted. You can close this page.</p></section> : <>
      <h2>Confirm account ownership</h2>
      <p>Enter the email address and password for the GigMate account you want to delete. Your password is sent to Supabase Auth for sign-in verification; it is not stored by GigMate.</p>
      <form onSubmit={submit} className="deletion-form">
        <label>Email address<input type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label>Password<input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        <button className="button" disabled={working || !email.trim() || !password}>{working ? 'Processing…' : 'Permanently delete my account'}</button>
      </form>
      {message && <p className="deletion-message" role="alert">{message}</p>}
    </>}
    <h2>What will be deleted</h2>
    <p>Your authentication account, profile, avatar where possible, gig listings submitted by your account, artist and venue directory records created by your account, saved gigs, friend requests, blocks, crew memberships, votes and reports. Artist and venue names retained as plain text in another member’s event details may remain so those events still make sense. Security records required by law may be retained for the period required.</p>
    <p>Read the <a href="/privacy.html">GigMate Privacy Policy</a> for the applicable data-retention details. The operator must complete the policy and publish a monitored support contact before public launch.</p>
  </main>
}

ReactDOM.createRoot(document.getElementById('delete-root')!).render(<DeleteAccountPage />)
