import { type FormEvent, useCallback, useEffect, useMemo, useState } from 'react'
import type { Session, SupabaseClient } from '@supabase/supabase-js'
import {
  AlertCircle, ArrowUpRight, Bell, CalendarDays, Check, ChevronDown, CircleUserRound,
  Compass, Copy, Guitar, Heart, MapPin, Menu, Music2, Plus, Search, ShieldCheck,
  Ticket, Users, X, LogOut, LoaderCircle, Building2, UserPlus, CalendarPlus,
} from 'lucide-react'
import { errorMessage, formatDate, getAvatarUrl, isSupabaseConfigured, supabase } from './lib'

type Page = 'for-you' | 'discover' | 'submit' | 'crew' | 'saved' | 'profile' | 'moderation'
type Profile = {
  id: string; username: string; display_name: string; bio: string; suburb: string; state: string; avatar_path: string | null; updated_at?: string
}
type Gig = {
  id: string; title: string; description: string; starts_at: string; is_free: boolean; price_from: number | null;
  ticket_url: string | null; venue_name: string; suburb: string; state: string; country: string; status: string;
  event_lineup?: { artist_name: string; position: number }[]
}
type Crew = { id: string; name: string; invite_code: string; role: string }
type DirectoryItem = { id: string; name: string; bio?: string; genres?: string[]; suburb?: string; state?: string; website_url?: string }
type EventReport = { id: string; event_id: string; reporter_id: string; reason: string; status: string; created_at: string; events?: { title: string; venue_name: string; starts_at: string } | null }

const sb = supabase
const ticketmasterEnabled = import.meta.env.VITE_TICKETMASTER_ENABLED === 'true'

function localDateTimeDefault() {
  const date = new Date(Date.now() + 24 * 60 * 60 * 1000)
  date.setMinutes(date.getMinutes() - date.getTimezoneOffset())
  return date.toISOString().slice(0, 16)
}

function App() {
  const [session, setSession] = useState<Session | null>(null)
  const [sessionLoading, setSessionLoading] = useState(true)
  const [passwordRecovery, setPasswordRecovery] = useState(false)
  const [page, setPage] = useState<Page>('for-you')
  const [events, setEvents] = useState<Gig[]>([])
  const [savedIds, setSavedIds] = useState<string[]>([])
  const [profile, setProfile] = useState<Profile | null>(null)
  const [crews, setCrews] = useState<Crew[]>([])
  const [crewVotes, setCrewVotes] = useState<Record<string, { going: number; maybe: number; not_going: number; total: number }>>({})
  const [voteRefresh, setVoteRefresh] = useState(0)
  const [staff, setStaff] = useState(false)
  const [loadingEvents, setLoadingEvents] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [search, setSearch] = useState('')
  const [locationFilter, setLocationFilter] = useState('')
  const [directoryTab, setDirectoryTab] = useState<'gigs' | 'artists' | 'venues'>('gigs')
  const [directoryItems, setDirectoryItems] = useState<DirectoryItem[]>([])
  const [ticketmasterResults, setTicketmasterResults] = useState<any[]>([])
  const [ticketmasterSearch, setTicketmasterSearch] = useState(false)
  const [selectedCrew, setSelectedCrew] = useState('')
  const [selectedEvent, setSelectedEvent] = useState<Gig | null>(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const user = session?.user ?? null

  const loadEvents = useCallback(async () => {
    if (!sb) return
    setLoadingEvents(true)
    const { data, error: queryError } = await sb
      .from('events')
      .select('id,title,description,starts_at,is_free,price_from,ticket_url,venue_name,suburb,state,country,status,event_lineup(artist_name,position)')
      .eq('status', 'approved')
      .gte('starts_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
      .order('starts_at', { ascending: true })
      .limit(150)
    if (queryError) setError(`Could not load gigs: ${queryError.message}`)
    else setEvents((data ?? []) as Gig[])
    setLoadingEvents(false)
  }, [])

  const loadMemberData = useCallback(async (memberId: string) => {
    if (!sb) return
    const [profileResult, savedResult, roleResult, crewResult] = await Promise.all([
      sb.from('profiles').select('id,username,display_name,bio,suburb,state,avatar_path').eq('id', memberId).maybeSingle(),
      sb.from('saved_events').select('event_id').eq('user_id', memberId),
      sb.from('user_roles').select('role').eq('user_id', memberId),
      sb.from('crew_members').select('role,crews(id,name,invite_code)').eq('user_id', memberId),
    ])
    if (profileResult.error) setError(`Could not load your profile: ${profileResult.error.message}`)
    else setProfile(profileResult.data as Profile | null)
    if (!savedResult.error) setSavedIds((savedResult.data ?? []).map((row: any) => row.event_id))
    if (!roleResult.error) setStaff((roleResult.data ?? []).some((row: any) => ['admin', 'moderator'].includes(row.role)))
    if (!crewResult.error) {
      setCrews((crewResult.data ?? []).map((row: any) => ({ ...row.crews, role: row.role })).filter(Boolean))
    }
  }, [])

  useEffect(() => {
    if (!sb) { setSessionLoading(false); return }
    let alive = true
    sb.auth.getSession().then(({ data, error: authError }) => {
      if (!alive) return
      if (authError) setError(authError.message)
      setSession(data.session)
      setSessionLoading(false)
    })
    const { data: listener } = sb.auth.onAuthStateChange((event, newSession) => {
      if (event === 'PASSWORD_RECOVERY') setPasswordRecovery(true)
      setSession(newSession)
      setProfile(null)
      setSavedIds([])
      setCrews([])
      setStaff(false)
      if (newSession?.user) {
        window.setTimeout(() => { void loadMemberData(newSession.user.id) }, 0)
      }
    })
    return () => { alive = false; listener.subscription.unsubscribe() }
  }, [loadMemberData])

  useEffect(() => { void loadEvents() }, [loadEvents])
  useEffect(() => {
    const sharedId = new URLSearchParams(window.location.search).get('event')
    if (sharedId && events.length) {
      const match = events.find((gig) => gig.id === sharedId)
      if (match) setSelectedEvent(match)
    }
  }, [events])
  useEffect(() => { if (user) void loadMemberData(user.id) }, [user?.id, loadMemberData])
  useEffect(() => { if (profile?.suburb && !locationFilter) setLocationFilter(profile.suburb) }, [profile?.id])
  useEffect(() => { if (crews.length && !selectedCrew) setSelectedCrew(crews[0].id) }, [crews, selectedCrew])
  useEffect(() => {
    if (!sb || !user || !crews.length || !events.length) { setCrewVotes({}); return }
    let cancelled = false
    const crewIds = crews.map((crew) => crew.id)
    const eventIds = events.map((gig) => gig.id)
    sb.from('crew_event_votes').select('crew_id,event_id,vote').in('crew_id', crewIds).in('event_id', eventIds).then(({ data, error: voteError }) => {
      if (cancelled) return
      if (voteError) { console.error('Crew vote summary could not be loaded:', voteError.message); return }
      const counts: Record<string, { going: number; maybe: number; not_going: number; total: number }> = {}
      ;(data ?? []).forEach((row: any) => {
        const key = `${row.crew_id}:${row.event_id}`
        counts[key] ??= { going: 0, maybe: 0, not_going: 0, total: 0 }
        counts[key][row.vote as 'going'|'maybe'|'not_going'] += 1
        counts[key].total += 1
      })
      setCrewVotes(counts)
    })
    return () => { cancelled = true }
  }, [user?.id, crews.map((crew) => crew.id).join(','), events.map((gig) => gig.id).join(','), voteRefresh])

  const filteredEvents = useMemo(() => {
    const q = search.trim().toLowerCase()
    const place = locationFilter.trim().toLowerCase()
    return events.filter((gig) => {
      const lineup = (gig.event_lineup ?? []).map((item) => item.artist_name).join(' ')
      const searchable = `${gig.title} ${gig.description} ${gig.venue_name} ${gig.suburb} ${gig.state} ${lineup}`.toLowerCase()
      return (!q || searchable.includes(q)) && (!place || `${gig.suburb} ${gig.state}`.toLowerCase().includes(place))
    })
  }, [events, search, locationFilter])

  const closeEventDetails = () => {
    setSelectedEvent(null)
    const url = new URL(window.location.href)
    url.searchParams.delete('event')
    window.history.replaceState({}, '', url.toString())
  }

  const showMessage = (message: string, isError = false) => {
    setError(isError ? message : '')
    setNotice(isError ? '' : message)
    window.setTimeout(() => { setNotice(''); setError('') }, 7000)
  }

  const toggleSave = async (gig: Gig) => {
    if (!sb) return
    if (!user) { setPage('profile'); showMessage('Sign in to save gigs to your account.'); return }
    setBusy(true)
    const exists = savedIds.includes(gig.id)
    const result = exists
      ? await sb.from('saved_events').delete().eq('user_id', user.id).eq('event_id', gig.id)
      : await sb.from('saved_events').insert({ user_id: user.id, event_id: gig.id })
    setBusy(false)
    if (result.error) showMessage(result.error.message, true)
    else {
      setSavedIds((current) => exists ? current.filter((id) => id !== gig.id) : [...current, gig.id])
      showMessage(exists ? 'Removed from your saved gigs.' : 'Gig saved to your account.')
    }
  }

  const shareGig = async (gig: Gig) => {
    const url = `${window.location.origin}/?event=${encodeURIComponent(gig.id)}`
    const shareData = { title: gig.title, text: `${gig.title} at ${gig.venue_name}, ${gig.suburb}`, url }
    try {
      if (navigator.share) await navigator.share(shareData)
      else if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(url); showMessage('Gig link copied.') }
      else showMessage('Sharing is not available in this browser.', true)
    } catch (err) {
      if (err instanceof Error && err.name !== 'AbortError') showMessage(err.message, true)
    }
  }

  const voteForCrew = async (gig: Gig, vote: 'going' | 'maybe' | 'not_going') => {
    if (!sb || !user) { setPage('profile'); showMessage('Sign in to plan gigs with your crew.'); return }
    if (!selectedCrew) { setPage('crew'); showMessage('Create or join a crew first.'); return }
    const { error: voteError } = await sb.from('crew_event_votes').upsert(
      { crew_id: selectedCrew, event_id: gig.id, user_id: user.id, vote },
      { onConflict: 'crew_id,event_id,user_id' },
    )
    if (voteError) showMessage(voteError.message, true)
    else { setVoteRefresh((value) => value + 1); showMessage(`Your ${vote.replace('_', ' ')} vote was shared with your crew.`) }
  }

  const submitReport = async (gig: Gig) => {
    if (!sb || !user) { setPage('profile'); showMessage('Sign in to report an event.'); return }
    const reason = window.prompt(`What needs checking about “${gig.title}”?`)
    if (!reason) return
    const { error: reportError } = await sb.from('event_reports').insert({ event_id: gig.id, reporter_id: user.id, reason })
    if (reportError) showMessage(reportError.message, true)
    else showMessage('Thanks. Your report has been sent to the moderation team.')
  }

  const loadDirectory = async (kind: 'artists' | 'venues') => {
    if (!sb) return
    const table = kind
    const columns = kind === 'artists' ? 'id,name,bio,genres,home_suburb,home_state,website_url' : 'id,name,description,suburb,state,website_url'
    const { data, error: directoryError } = await sb.from(table).select(columns).eq('status', 'approved').order('name').limit(100)
    if (directoryError) showMessage(directoryError.message, true)
    else setDirectoryItems((data ?? []).map((item: any) => kind === 'artists' ? ({ ...item, suburb: item.home_suburb, state: item.home_state }) : ({ ...item, bio: item.description })) as DirectoryItem[])
  }

  const searchTicketmaster = async () => {
    if (!sb || !user) { setPage('profile'); showMessage('Sign in to use external event search.'); return }
    setTicketmasterSearch(true)
    setTicketmasterResults([])
    const { data, error: fnError } = await sb.functions.invoke('search-ticketmaster', {
      body: { keyword: search.trim(), city: locationFilter.trim() },
    })
    setTicketmasterSearch(false)
    if (fnError) showMessage(fnError.message, true)
    else if (data?.error) showMessage(data.error, true)
    else setTicketmasterResults(data?.events ?? [])
  }

  if (!isSupabaseConfigured || !sb) return <SetupScreen />
  if (sessionLoading) return <div className="loading-screen"><LoaderCircle className="spin"/><span>Connecting to GigMate…</span></div>
  if (passwordRecovery) return <PasswordRecoveryPage onDone={() => { setPasswordRecovery(false); showMessage('Your password has been updated.') }} onMessage={showMessage}/>

  const navItems: { id: Page; label: string; icon: typeof Compass }[] = [
    { id: 'for-you', label: 'For You', icon: Music2 },
    { id: 'discover', label: 'Discover', icon: Compass },
    { id: 'submit', label: 'Submit a gig', icon: CalendarPlus },
    { id: 'crew', label: 'Your Crew', icon: Users },
    { id: 'saved', label: 'Saved', icon: Heart },
  ]
  if (staff) navItems.push({ id: 'moderation', label: 'Moderation', icon: ShieldCheck })

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top" onClick={(e) => { e.preventDefault(); setPage('for-you') }}>
          <span className="brand-mark"><Music2 size={20}/></span>
          <span>Gig<span className="pink">Mate</span><i>✦</i></span>
        </a>
        <p className="tagline">Find every gig. Especially the little ones.</p>
        <div className="top-actions">
          {user ? (
            <button className="profile-pill" onClick={() => setPage('profile')} title="Open your profile">
              {profile?.avatar_path ? <img src={getAvatarUrl(profile.avatar_path) ?? ''} alt=""/> : <CircleUserRound size={18}/>}<span>{profile?.display_name || 'Your account'}</span>
            </button>
          ) : <button className="button button-small" onClick={() => setPage('profile')}>Sign in</button>}
          <button className="icon-button menu-toggle" aria-label="Toggle menu" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}><Menu size={19}/></button>
        </div>
      </header>

      <div className="app-layout">
        <aside className={`sidebar ${mobileMenuOpen ? 'open' : ''}`}>
          <div className="sidebar-label">YOUR GIGMATE</div>
          <nav className="side-nav">
            {navItems.map(({ id, label, icon: Icon }) => (
              <button key={id} className={`nav-link ${page === id ? 'active' : ''}`} onClick={() => { setPage(id); setMobileMenuOpen(false) }}>
                <Icon size={18}/><span>{label}</span>
                {id === 'submit' && <Plus size={15} className="nav-trailing"/>}
              </button>
            ))}
          </nav>
          <div className="sidebar-note">
            <div className="note-icon"><Guitar size={18}/></div>
            <b>Back the local scene.</b>
            <p>Know a gig that's missing? Add it so nobody misses out.</p>
            <button className="text-action" onClick={() => { setPage('submit'); setMobileMenuOpen(false) }}>Add a local gig <ArrowUpRight size={14}/></button>
          </div>
          <div className="sidebar-footer">GigMate · Built for live music</div>
        </aside>

        <main className="main-content">
          {(notice || error) && <div className={`toast ${error ? 'toast-error' : ''}`} role="status"><span>{error ? <AlertCircle size={17}/> : <Check size={17}/>}</span>{error || notice}<button onClick={() => { setError(''); setNotice('') }} aria-label="Dismiss"><X size={16}/></button></div>}

          {page === 'for-you' && (
            <>
              <section className="hero-panel">
                <div className="hero-copy"><span className="eyebrow">YOUR LOCAL LIVE MUSIC GUIDE</span><h1>Big nights start<br/>with <em>small discoveries.</em></h1><p>Find the pub gigs, emerging artists and last-minute shows that don't always make the big ticket sites.</p><button className="button" onClick={() => setPage('discover')}>Explore local gigs <ArrowUpRight size={16}/></button></div>
                <div className="hero-art" aria-hidden="true"><div className="halo halo-one"/><div className="halo halo-two"/><div className="vinyl"><div className="vinyl-hole"/><span>LIVE<br/>MUSIC</span></div><div className="spark spark-a">✦</div><div className="spark spark-b">✳</div></div>
              </section>
              <div className="section-heading"><div><span className="eyebrow">ON THE RADAR</span><h2>Upcoming near you</h2><p>Approved community-submitted gigs and local listings.</p></div><button className="text-action" onClick={() => setPage('discover')}>See all <ArrowUpRight size={15}/></button></div>
              <div className="filter-row"><label className="field-inline"><MapPin size={16}/><input value={locationFilter} onChange={(e) => setLocationFilter(e.target.value)} placeholder="Filter by suburb or state" aria-label="Filter by suburb or state"/></label><button className="filter-reset" onClick={() => setLocationFilter('')}>Clear</button></div>
              <EventList events={filteredEvents.slice(0, 8)} loading={loadingEvents} savedIds={savedIds} crews={crews} selectedCrew={selectedCrew} crewVotes={crewVotes} onSelectedCrew={setSelectedCrew} onSave={toggleSave} onShare={shareGig} onVote={voteForCrew} onReport={submitReport} onOpen={setSelectedEvent} onSubmit={() => setPage('submit')}/>
            </>
          )}

          {page === 'discover' && (
            <>
              <div className="page-intro"><span className="eyebrow">GET OUT THERE</span><h1>Discover your next gig.</h1><p>Search local shows, grassroots artists and the venues putting them on.</p></div>
              <div className="search-panel"><div className="search-box"><Search size={19}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Artist, band, venue or music style…"/></div><div className="search-box location-search"><MapPin size={18}/><input value={locationFilter} onChange={(e) => setLocationFilter(e.target.value)} placeholder="Suburb, town or state"/></div><button className="button" onClick={() => { setDirectoryTab('gigs'); void loadEvents() }}>Search gigs</button></div>
              <div className="tab-row"><button className={directoryTab === 'gigs' ? 'selected' : ''} onClick={() => setDirectoryTab('gigs')}>Gigs</button><button className={directoryTab === 'artists' ? 'selected' : ''} onClick={() => { setDirectoryTab('artists'); void loadDirectory('artists') }}>Artists</button><button className={directoryTab === 'venues' ? 'selected' : ''} onClick={() => { setDirectoryTab('venues'); void loadDirectory('venues') }}>Venues</button></div>
              {directoryTab === 'gigs' ? <>
                <EventList events={filteredEvents} loading={loadingEvents} savedIds={savedIds} crews={crews} selectedCrew={selectedCrew} crewVotes={crewVotes} onSelectedCrew={setSelectedCrew} onSave={toggleSave} onShare={shareGig} onVote={voteForCrew} onReport={submitReport} onOpen={setSelectedEvent} onSubmit={() => setPage('submit')}/>
                {ticketmasterEnabled && <section className="external-search"><div><b>Search the wider event feed</b><p>Optional Ticketmaster listings supplement community-submitted gigs.</p></div><button className="button button-outline" onClick={searchTicketmaster} disabled={ticketmasterSearch || (!search.trim() && !locationFilter.trim())}>{ticketmasterSearch ? <LoaderCircle className="spin" size={16}/> : <Search size={16}/>} Search Ticketmaster</button>{ticketmasterResults.length > 0 && <div className="external-results">{ticketmasterResults.map((item: any) => <div className="external-item" key={item.id}><b>{item.name}</b><span>{item.venue} · {item.city} {item.state}</span>{item.startsAt && <small>{new Date(item.startsAt).toLocaleString()}</small>}{item.url && <a href={item.url} target="_blank" rel="noreferrer">Official event page <ArrowUpRight size={13}/></a>}</div>)}</div>}</section>}
              </> : <DirectoryList kind={directoryTab} items={directoryItems} />}
            </>
          )}

          {page === 'submit' && <SubmitGig user={user} onDone={async () => { await loadEvents(); setPage('for-you') }} onMessage={showMessage} />}
          {page === 'crew' && <CrewPage user={user} crews={crews} onCrewsChanged={() => user && loadMemberData(user.id)} onMessage={showMessage} />}
          {page === 'saved' && <SavedPage events={events.filter((gig) => savedIds.includes(gig.id))} loading={loadingEvents} savedIds={savedIds} crews={crews} selectedCrew={selectedCrew} crewVotes={crewVotes} onSelectedCrew={setSelectedCrew} onSave={toggleSave} onShare={shareGig} onVote={voteForCrew} onReport={submitReport} onOpen={setSelectedEvent} onSubmit={() => setPage('submit')} user={user} onMessage={showMessage} />}
          {page === 'profile' && <ProfilePage user={user} profile={profile} onProfileUpdated={setProfile} onMessage={showMessage} />}
          {page === 'moderation' && staff && <ModerationPage onMessage={showMessage} onChanged={loadEvents} />}
          {selectedEvent && <EventDetails gig={selectedEvent} onClose={closeEventDetails} onSave={() => void toggleSave(selectedEvent)} saved={savedIds.includes(selectedEvent.id)} onShare={() => void shareGig(selectedEvent)} />}
        </main>
      </div>
      <div className="site-footer"><span>GigMate · Local music, found together.</span><div><a href="/privacy.html" target="_blank" rel="noreferrer">Privacy</a><a href="/terms.html" target="_blank" rel="noreferrer">Terms</a><a href="/delete-account.html" target="_blank" rel="noreferrer">Delete account</a><a href="https://supabase.com/docs" target="_blank" rel="noreferrer">Supabase docs</a></div></div>
      <footer className="mobile-footer"><button className={page === 'for-you' ? 'active' : ''} onClick={() => setPage('for-you')}><Music2/><span>For You</span></button><button className={page === 'discover' ? 'active' : ''} onClick={() => setPage('discover')}><Compass/><span>Discover</span></button><button className={page === 'submit' ? 'active' : ''} onClick={() => setPage('submit')}><Plus/><span>Submit</span></button><button className={page === 'crew' ? 'active' : ''} onClick={() => setPage('crew')}><Users/><span>Crew</span></button><button className={page === 'saved' ? 'active' : ''} onClick={() => setPage('saved')}><Heart/><span>Saved</span></button></footer>
    </div>
  )
}

function SetupScreen() {
  return <div className="setup-screen"><div className="setup-card"><div className="brand"><span className="brand-mark"><Music2/></span><span>Gig<span className="pink">Mate</span>✦</span></div><span className="eyebrow">BACKEND SETUP REQUIRED</span><h1>Connect GigMate to its real backend.</h1><p>This build deliberately contains no sample gigs or pretend account actions. Add your Supabase project details to make sign-in, profiles, saved gigs, crew planning and submissions work.</p><ol><li>Create a Supabase project.</li><li>Copy <code>.env.example</code> to <code>.env.local</code>.</li><li>Add your project URL and publishable key.</li><li>Run the SQL migration in <code>supabase/migrations</code>.</li></ol><a className="button" href="https://supabase.com/dashboard" target="_blank" rel="noreferrer">Open Supabase <ArrowUpRight size={16}/></a><p className="setup-foot">No API keys are embedded in this application. Never put a service-role key or payment secret in browser code.</p></div></div>
}

function AuthPanel({ onMessage }: { onMessage: (message: string, isError?: boolean) => void }) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [username, setUsername] = useState('')
  const [loading, setLoading] = useState(false)
  const [resetting, setResetting] = useState(false)
  const resetPassword = async () => {
    if (!sb) return
    if (!email.trim()) { onMessage('Enter your email address first so we know where to send the reset link.', true); return }
    setResetting(true)
    const { error: resetError } = await sb.auth.resetPasswordForEmail(email.trim(), { redirectTo: window.location.origin })
    setResetting(false)
    if (resetError) onMessage(resetError.message, true)
    else onMessage('Password reset email sent. Follow its link to choose a new password.')
  }
  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!sb) return
    setLoading(true)
    const result = mode === 'signin'
      ? await sb.auth.signInWithPassword({ email: email.trim(), password })
      : await sb.auth.signUp({ email: email.trim(), password, options: { data: { display_name: displayName.trim(), username: username.trim() }, emailRedirectTo: window.location.origin } })
    setLoading(false)
    if (result.error) onMessage(result.error.message, true)
    else if (mode === 'signup' && !result.data.session) onMessage('Account created. Check your email to confirm your address, then sign in.')
    else onMessage(mode === 'signin' ? 'You are signed in.' : 'Your GigMate account is ready.')
  }
  return <div className="auth-card"><div className="auth-switch"><button className={mode === 'signin' ? 'selected' : ''} onClick={() => setMode('signin')}>Sign in</button><button className={mode === 'signup' ? 'selected' : ''} onClick={() => setMode('signup')}>Create account</button></div><form onSubmit={submit} className="stack-form">{mode === 'signup' && <><label>Display name<input required value={displayName} onChange={(e) => setDisplayName(e.target.value)} minLength={2} maxLength={60} placeholder="How people see you"/></label><label>Username<input required value={username} onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))} minLength={3} maxLength={24} placeholder="yourusername"/></label></>}<label>Email address<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com"/></label><label>Password<input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === 'signin' ? 'current-password' : 'new-password'} placeholder="At least 8 characters"/></label><button className="button button-wide" disabled={loading}>{loading ? <LoaderCircle className="spin" size={17}/> : null}{mode === 'signin' ? 'Sign in' : 'Create my account'}</button></form>{mode === 'signin' && <button type="button" className="text-action forgot-password" onClick={() => void resetPassword()} disabled={resetting}>{resetting ? <LoaderCircle size={14} className="spin"/> : null}Forgot your password?</button>}<p className="fine-print">Email confirmation and password recovery links are sent through your Supabase Auth email settings.</p></div>
}

function PasswordRecoveryPage({ onDone, onMessage }: { onDone: () => void; onMessage: (message: string, isError?: boolean) => void }) {
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [saving, setSaving] = useState(false)
  const save = async (event: FormEvent) => {
    event.preventDefault()
    if (!sb) return
    if (password.length < 8) { onMessage('Choose a password with at least 8 characters.', true); return }
    if (password !== confirmPassword) { onMessage('The passwords do not match.', true); return }
    setSaving(true)
    const { error: updateError } = await sb.auth.updateUser({ password })
    setSaving(false)
    if (updateError) onMessage(updateError.message, true)
    else onDone()
  }
  return <div className="setup-screen"><div className="setup-card"><div className="brand"><span className="brand-mark"><Music2/></span><span>Gig<span className="pink">Mate</span>✦</span></div><span className="eyebrow">ACCOUNT SECURITY</span><h1>Choose a new password.</h1><p>Set a new password for your GigMate account.</p><form className="stack-form" onSubmit={save}><label>New password<input type="password" autoComplete="new-password" minLength={8} required value={password} onChange={(e) => setPassword(e.target.value)}/></label><label>Confirm new password<input type="password" autoComplete="new-password" minLength={8} required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}/></label><button className="button button-wide" disabled={saving}>{saving ? <LoaderCircle className="spin" size={17}/> : <Check size={17}/>} Update password</button></form></div></div>
}

function ProfilePage({ user, profile, onProfileUpdated, onMessage }: { user: Session['user'] | null; profile: Profile | null; onProfileUpdated: (profile: Profile) => void; onMessage: (message: string, isError?: boolean) => void }) {
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '')
  const [username, setUsername] = useState(profile?.username ?? '')
  const [bio, setBio] = useState(profile?.bio ?? '')
  const [suburb, setSuburb] = useState(profile?.suburb ?? '')
  const [state, setState] = useState(profile?.state ?? '')
  const [saving, setSaving] = useState(false)
  useEffect(() => { setDisplayName(profile?.display_name ?? ''); setUsername(profile?.username ?? ''); setBio(profile?.bio ?? ''); setSuburb(profile?.suburb ?? ''); setState(profile?.state ?? '') }, [profile?.id, profile?.updated_at])
  if (!user) return <div className="page-intro"><span className="eyebrow">YOUR ACCOUNT</span><h1>Join the GigMate community.</h1><p>Create an account to submit gigs, save shows, make friends and plan with your crew.</p><AuthPanel onMessage={onMessage}/></div>
  const save = async (event: FormEvent) => {
    event.preventDefault()
    if (!sb) return
    setSaving(true)
    const { data, error: updateError } = await sb.from('profiles').update({ display_name: displayName.trim(), username: username.trim(), bio: bio.trim(), suburb: suburb.trim(), state: state.trim() }).eq('id', user.id).select('id,username,display_name,bio,suburb,state,avatar_path').single()
    setSaving(false)
    if (updateError) onMessage(updateError.message, true)
    else { onProfileUpdated(data as Profile); onMessage('Your profile has been saved.') }
  }
  const deleteAccount = async () => {
    if (!sb) return
    const confirmed = window.confirm('Permanently delete your GigMate account and profile? This cannot be undone.')
    if (!confirmed) return
    setSaving(true)
    const { error: deleteError } = await sb.functions.invoke('delete-account', { body: {} })
    setSaving(false)
    if (deleteError) onMessage(deleteError.message, true)
    else { await sb.auth.signOut(); onMessage('Your GigMate account has been deleted.') }
  }
  const uploadAvatar = async (file?: File) => {
    if (!file || !sb) return
    if (!['image/jpeg','image/png','image/webp'].includes(file.type)) { onMessage('Choose a JPG, PNG or WebP image.', true); return }
    if (file.size > 5 * 1024 * 1024) { onMessage('Profile images must be 5 MB or smaller.', true); return }
    const extension = file.type.split('/')[1].replace('jpeg','jpg')
    const path = `${user.id}/${crypto.randomUUID()}.${extension}`
    const { error: uploadError } = await sb.storage.from('avatars').upload(path, file, { upsert: false, contentType: file.type })
    if (uploadError) { onMessage(uploadError.message, true); return }
    const { data, error: saveError } = await sb.from('profiles').update({ avatar_path: path }).eq('id', user.id).select('id,username,display_name,bio,suburb,state,avatar_path').single()
    if (saveError) onMessage(saveError.message, true)
    else { onProfileUpdated(data as Profile); onMessage('Profile photo updated.') }
  }
  return <div className="page-intro"><span className="eyebrow">YOUR SPACE</span><h1>Your profile.</h1><p>Make it easier for other music fans and local artists to find you.</p><div className="profile-card"><div className="profile-avatar">{profile?.avatar_path ? <img src={getAvatarUrl(profile.avatar_path) ?? ''} alt="Profile"/> : <CircleUserRound size={42}/>}</div><div><h2>{profile?.display_name || displayName || 'GigMate member'}</h2><span>@{profile?.username || username || 'username'}</span></div><label className="upload-avatar">Change photo<input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => void uploadAvatar(e.target.files?.[0])}/></label></div><form className="stack-form profile-form" onSubmit={save}><label>Display name<input required minLength={2} maxLength={60} value={displayName} onChange={(e) => setDisplayName(e.target.value)}/></label><label>Username<input required minLength={3} maxLength={24} pattern="[a-zA-Z0-9_]+" value={username} onChange={(e) => setUsername(e.target.value.toLowerCase())}/></label><label>Bio<textarea rows={3} maxLength={240} value={bio} onChange={(e) => setBio(e.target.value)} placeholder="A little about your music taste…"/></label><div className="form-grid"><label>Suburb or town<input value={suburb} onChange={(e) => setSuburb(e.target.value)}/></label><label>State or territory<input value={state} onChange={(e) => setState(e.target.value)} placeholder="QLD"/></label></div><button className="button" disabled={saving}>{saving ? <LoaderCircle size={16} className="spin"/> : <Check size={16}/>} Save profile</button></form><div className="account-actions"><button className="button button-quiet signout" onClick={async () => { await sb?.auth.signOut(); onMessage('You have signed out.') }}><LogOut size={16}/> Sign out</button><button className="delete-account" disabled={saving} onClick={() => void deleteAccount()}>Delete my account</button></div></div>
}

function SubmitGig({ user, onDone, onMessage }: { user: Session['user'] | null; onDone: () => Promise<void>; onMessage: (message: string, isError?: boolean) => void }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [venue, setVenue] = useState('')
  const [suburb, setSuburb] = useState('')
  const [state, setState] = useState('QLD')
  const [startsAt, setStartsAt] = useState(localDateTimeDefault())
  const [lineup, setLineup] = useState('')
  const [isFree, setIsFree] = useState(false)
  const [price, setPrice] = useState('')
  const [ticketUrl, setTicketUrl] = useState('')
  const [submitting, setSubmitting] = useState(false)
  if (!user) return <div className="page-intro"><span className="eyebrow">HELP THE SCENE</span><h1>Got a gig to share?</h1><p>Sign in to submit a local show. Your listing goes through a quick community moderation check before it appears publicly.</p><AuthPanel onMessage={onMessage}/></div>
  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!sb) return
    setSubmitting(true)
    const { error: submitError } = await sb.rpc('submit_gig', {
      p_title: title.trim(), p_description: description.trim(), p_starts_at: new Date(startsAt).toISOString(),
      p_venue_name: venue.trim(), p_suburb: suburb.trim(), p_state: state.trim().toUpperCase(),
      p_lineup: lineup.split(/[\n,;]/).map((name) => name.trim()).filter(Boolean),
      p_is_free: isFree, p_price_from: isFree || !price ? null : Number(price), p_ticket_url: ticketUrl.trim() || null,
    })
    setSubmitting(false)
    if (submitError) onMessage(submitError.message, true)
    else { onMessage('Gig submitted. It will appear publicly after a moderator approves it.'); await onDone() }
  }
  return <div className="page-intro narrow"><span className="eyebrow">COMMUNITY SUBMISSION</span><h1>Put a local gig on the map.</h1><p>Small bands, pub shows, support slots, acoustic afternoons and last-minute line-ups all belong here.</p><form className="stack-form submit-form" onSubmit={submit}><label>Gig or event name<input required minLength={4} maxLength={140} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Friday local bands night"/></label><label>Venue name<input required minLength={2} value={venue} onChange={(e) => setVenue(e.target.value)} placeholder="Pub, club, hall or outdoor space"/></label><div className="form-grid"><label>Suburb or town<input required minLength={2} value={suburb} onChange={(e) => setSuburb(e.target.value)} placeholder="Fortitude Valley"/></label><label>State or territory<input required minLength={2} maxLength={3} value={state} onChange={(e) => setState(e.target.value)} placeholder="QLD"/></label></div><label>Date and time<input required type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)}/></label><label>Artists on the line-up <span className="optional">Separate names with commas or new lines</span><textarea rows={3} value={lineup} onChange={(e) => setLineup(e.target.value)} placeholder={'The local band\nSupport artist\nDJ after the show'}/></label><label>Description<textarea rows={4} maxLength={2000} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What should people know about the night?"/></label><label className="check-row"><input type="checkbox" checked={isFree} onChange={(e) => setIsFree(e.target.checked)}/> Free entry</label>{!isFree && <label>Ticket price from (AUD)<input type="number" min="0" step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="e.g. 15"/></label>}<label>Official ticket or event link <span className="optional">Optional</span><input type="url" value={ticketUrl} onChange={(e) => setTicketUrl(e.target.value)} placeholder="https://…"/></label><div className="review-note"><ShieldCheck size={18}/><span><b>Reviewed before publishing.</b> Your event and any new artist or venue profiles are submitted for moderation first. Nothing goes live automatically.</span></div><button className="button button-wide" disabled={submitting}>{submitting ? <LoaderCircle size={17} className="spin"/> : <CalendarPlus size={17}/>} Submit gig for review</button></form></div>
}

function EventList({ events, loading, savedIds, crews, selectedCrew, crewVotes, onSelectedCrew, onSave, onShare, onVote, onReport, onOpen, onSubmit }: {
  events: Gig[]; loading: boolean; savedIds: string[]; crews: Crew[]; selectedCrew: string; crewVotes: Record<string, { going: number; maybe: number; not_going: number; total: number }>; onSelectedCrew: (id: string) => void;
  onSave: (gig: Gig) => void; onShare: (gig: Gig) => void; onVote: (gig: Gig, vote: 'going'|'maybe'|'not_going') => void; onReport: (gig: Gig) => void; onOpen: (gig: Gig) => void; onSubmit: () => void
}) {
  if (loading && !events.length) return <div className="empty-state"><LoaderCircle className="spin"/><p>Loading approved gigs…</p></div>
  if (!events.length) return <div className="empty-state"><div className="empty-icon"><CalendarDays size={27}/></div><h3>No approved gigs found yet.</h3><p>We don't fill this feed with invented listings. Add a real local show or try another suburb.</p><button className="button" onClick={onSubmit}><Plus size={16}/> Submit a local gig</button></div>
  return <div className="event-grid">{events.map((gig) => <article className="event-card" key={gig.id}><div className="event-date"><span>{new Date(gig.starts_at).toLocaleDateString(undefined,{month:'short'}).toUpperCase()}</span><b>{new Date(gig.starts_at).getDate()}</b><small>{new Date(gig.starts_at).toLocaleDateString(undefined,{weekday:'short'}).toUpperCase()}</small></div><div className="event-main"><div className="event-topline"><span className="event-local"><MapPin size={13}/>{gig.suburb}, {gig.state}</span><span className="verified-label"><Check size={12}/> Reviewed</span></div><h3><button className="event-title-button" onClick={() => onOpen(gig)}>{gig.title}</button></h3><div className="event-venue"><Building2 size={14}/>{gig.venue_name}</div><div className="event-time"><CalendarDays size={14}/>{formatDate(gig.starts_at)}</div>{(gig.event_lineup ?? []).length > 0 && <div className="lineup"><span>LINE-UP</span>{(gig.event_lineup ?? []).sort((a,b)=>a.position-b.position).map((item) => item.artist_name).join(' · ')}</div>}{gig.description && <p className="event-description">{gig.description}</p>}<div className="event-bottom"><span className="price-label">{gig.is_free ? 'FREE ENTRY' : gig.price_from != null ? `FROM $${Number(gig.price_from).toFixed(2)}` : 'PRICE NOT LISTED'}</span><div className="event-actions"><button className={`icon-button ${savedIds.includes(gig.id) ? 'saved' : ''}`} onClick={() => onSave(gig)} title={savedIds.includes(gig.id) ? 'Remove from saved' : 'Save gig'} aria-label="Save gig"><Heart size={17} fill={savedIds.includes(gig.id) ? 'currentColor' : 'none'}/></button><button className="icon-button" onClick={() => onShare(gig)} title="Share gig" aria-label="Share gig"><ArrowUpRight size={17}/></button><button className="report-link" onClick={() => onReport(gig)}>Report</button></div></div>{crews.length > 0 && <div className="crew-vote"><select value={selectedCrew} onChange={(e) => onSelectedCrew(e.target.value)} aria-label="Choose crew">{crews.map((crew) => <option value={crew.id} key={crew.id}>{crew.name}</option>)}</select><button onClick={() => onVote(gig,'going')}>Going</button><button onClick={() => onVote(gig,'maybe')}>Maybe</button>{crewVotes[`${selectedCrew}:${gig.id}`]?.total ? <span className="vote-summary">{crewVotes[`${selectedCrew}:${gig.id}`].going} going · {crewVotes[`${selectedCrew}:${gig.id}`].maybe} maybe</span> : null}</div>}{gig.ticket_url && <a className="official-ticket-link" href={gig.ticket_url} target="_blank" rel="noreferrer">Official event / ticket link <ArrowUpRight size={13}/></a>}</div></article>)}</div>
}


function EventDetails({ gig, onClose, onSave, saved, onShare }: { gig: Gig; onClose: () => void; onSave: () => void; saved: boolean; onShare: () => void }) {
  return <div className="modal-backdrop" role="presentation" onClick={(event) => { if (event.target === event.currentTarget) onClose() }}><section className="event-modal" role="dialog" aria-modal="true" aria-labelledby="event-modal-title"><button className="modal-close icon-button" onClick={onClose} aria-label="Close event details"><X/></button><span className="eyebrow">GIG DETAILS · REVIEWED LISTING</span><div className="modal-date">{formatDate(gig.starts_at)}</div><h2 id="event-modal-title">{gig.title}</h2><p className="modal-location"><MapPin size={15}/>{gig.venue_name} · {gig.suburb}, {gig.state}</p>{gig.description && <p className="modal-description">{gig.description}</p>}{(gig.event_lineup ?? []).length > 0 && <div className="modal-lineup"><b>ON THE LINE-UP</b>{(gig.event_lineup ?? []).sort((a,b)=>a.position-b.position).map((artist) => <span key={`${artist.artist_name}-${artist.position}`}>{artist.artist_name}</span>)}</div>}<div className="modal-price">{gig.is_free ? 'Free entry' : gig.price_from != null ? `Tickets from $${Number(gig.price_from).toFixed(2)} AUD` : 'Ticket price not supplied'}</div><div className="modal-actions"><button className="button" onClick={onSave}><Heart size={16} fill={saved ? 'currentColor' : 'none'}/>{saved ? 'Saved' : 'Save gig'}</button><button className="button button-outline" onClick={onShare}><ArrowUpRight size={16}/> Share</button>{gig.ticket_url && <a className="button button-quiet" href={gig.ticket_url} target="_blank" rel="noreferrer">Official ticket / event page <ArrowUpRight size={14}/></a>}</div></section></div>
}

function DirectoryList({ kind, items }: { kind: 'artists' | 'venues'; items: DirectoryItem[] }) {
  if (!items.length) return <div className="empty-state"><div className="empty-icon">{kind === 'artists' ? <Music2/> : <Building2/>}</div><h3>No approved {kind} yet.</h3><p>Artist and venue pages are created from community gig submissions and appear after review.</p></div>
  return <div className="directory-list">{items.map((item) => <article className="directory-card" key={item.id}><div className="directory-icon">{kind === 'artists' ? <Guitar/> : <Building2/>}</div><div><h3>{item.name}</h3><p>{kind === 'artists' ? item.genres?.join(' · ') || item.bio || 'Local artist' : item.bio || 'Local music venue'}</p><span>{item.suburb || ''}{item.state ? `, ${item.state}` : ''}</span></div>{item.website_url && <a href={item.website_url} target="_blank" rel="noreferrer" aria-label={`Open ${item.name} website`}><ArrowUpRight/></a>}</article>)}</div>
}

function SavedPage({ events, loading, savedIds, crews, selectedCrew, crewVotes, onSelectedCrew, onSave, onShare, onVote, onReport, onOpen, onSubmit, user, onMessage }: any) {
  if (!user) return <div className="page-intro"><span className="eyebrow">YOUR SHORTLIST</span><h1>Keep your favourite gigs close.</h1><p>Sign in to save events and see them on any device.</p><AuthPanel onMessage={onMessage}/></div>
  return <><div className="page-intro"><span className="eyebrow">YOUR SHORTLIST</span><h1>Saved gigs.</h1><p>Your saved shows are synced to your account, not just this browser.</p></div><EventList events={events} loading={loading} savedIds={savedIds} crews={crews} selectedCrew={selectedCrew} crewVotes={crewVotes} onSelectedCrew={onSelectedCrew} onSave={onSave} onShare={onShare} onVote={onVote} onReport={onReport} onOpen={onOpen} onSubmit={onSubmit}/></>
}

function CrewPage({ user, crews, onCrewsChanged, onMessage }: { user: Session['user'] | null; crews: Crew[]; onCrewsChanged: () => void; onMessage: (message: string, isError?: boolean) => void }) {
  const [crewName, setCrewName] = useState('')
  const [inviteCode, setInviteCode] = useState('')
  const [friendSearch, setFriendSearch] = useState('')
  const [friendResults, setFriendResults] = useState<Profile[]>([])
  const [requests, setRequests] = useState<any[]>([])
  const [people, setPeople] = useState<Record<string, Profile>>({})
  const [blockedMembers, setBlockedMembers] = useState<Profile[]>([])
  const [busy, setBusy] = useState(false)
  const [inviteCopied, setInviteCopied] = useState('')
  const loadRequests = useCallback(async () => {
    if (!sb || !user) return
    const { data, error: requestError } = await sb.from('friend_requests').select('*').or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`).order('created_at', { ascending: false })
    if (requestError) { onMessage(requestError.message, true); return }
    const rows = data ?? []
    setRequests(rows)
    const ids = [...new Set(rows.map((row: any) => row.sender_id === user.id ? row.recipient_id : row.sender_id))]
    if (ids.length) {
      const { data: profiles } = await sb.from('profiles').select('id,username,display_name,bio,suburb,state,avatar_path').in('id', ids)
      const map: Record<string, Profile> = {}
      ;(profiles ?? []).forEach((item: any) => { map[item.id] = item })
      setPeople(map)
    } else setPeople({})
  }, [user?.id])
  const loadBlocked = useCallback(async () => {
    if (!sb || !user) return
    const { data, error: blockedError } = await sb.rpc('list_blocked_members')
    if (blockedError) onMessage(blockedError.message, true)
    else setBlockedMembers((data ?? []) as Profile[])
  }, [user?.id])
  useEffect(() => { void loadRequests(); void loadBlocked() }, [loadRequests, loadBlocked])
  if (!user) return <div className="page-intro"><span className="eyebrow">BETTER TOGETHER</span><h1>Find your people.</h1><p>Sign in to add friends, build crews and vote on the gigs you want to attend together.</p><AuthPanel onMessage={onMessage}/></div>
  const searchFriends = async (event: FormEvent) => {
    event.preventDefault()
    if (!sb || friendSearch.trim().length < 2) return
    const { data, error: searchError } = await sb.from('profiles').select('id,username,display_name,bio,suburb,state,avatar_path').ilike('username', `%${friendSearch.trim()}%`).neq('id', user.id).limit(10)
    if (searchError) onMessage(searchError.message, true)
    else setFriendResults((data ?? []) as Profile[])
  }
  const sendRequest = async (username: string) => {
    if (!sb) return
    const { error: requestError } = await sb.rpc('send_friend_request', { p_username: username })
    if (requestError) onMessage(requestError.message, true)
    else { onMessage(`Friend request sent to @${username}.`); await loadRequests() }
  }
  const respond = async (id: string, accept: boolean) => {
    if (!sb) return
    const { error: responseError } = await sb.rpc('respond_friend_request', { p_request_id: id, p_accept: accept })
    if (responseError) onMessage(responseError.message, true)
    else { onMessage(accept ? 'Friend request accepted.' : 'Friend request declined.'); await loadRequests() }
  }
  const blockMember = async (memberId: string, displayName: string) => {
    if (!sb || !window.confirm(`Block ${displayName}? They will be removed from your friend list, and their profile and submitted gigs will be hidden from you.`)) return
    const { error: blockError } = await sb.rpc('block_member', { p_user_id: memberId })
    if (blockError) onMessage(blockError.message, true)
    else { onMessage(`${displayName} has been blocked.`); setFriendResults((items) => items.filter((item) => item.id !== memberId)); await loadRequests(); await loadBlocked() }
  }
  const unblockMember = async (memberId: string) => {
    if (!sb) return
    const { error: unblockError } = await sb.rpc('unblock_member', { p_user_id: memberId })
    if (unblockError) onMessage(unblockError.message, true)
    else { onMessage('Member unblocked.'); await loadBlocked() }
  }
  const createCrew = async (event: FormEvent) => {
    event.preventDefault()
    if (!sb) return
    setBusy(true)
    const { data, error: createError } = await sb.rpc('create_crew', { p_name: crewName.trim() })
    setBusy(false)
    if (createError) onMessage(createError.message, true)
    else { setCrewName(''); onMessage(`Crew created. Share invite code ${(data?.[0]?.invite_code ?? '')} with friends.`); onCrewsChanged() }
  }
  const joinCrew = async (event: FormEvent) => {
    event.preventDefault()
    if (!sb) return
    setBusy(true)
    const { error: joinError } = await sb.rpc('join_crew', { p_invite_code: inviteCode.trim().toUpperCase() })
    setBusy(false)
    if (joinError) onMessage(joinError.message, true)
    else { setInviteCode(''); onMessage('You have joined the crew.'); onCrewsChanged() }
  }
  const copyCode = async (crew: Crew) => {
    try { await navigator.clipboard.writeText(crew.invite_code); setInviteCopied(crew.id); onMessage('Invite code copied.') }
    catch { onMessage(`Invite code: ${crew.invite_code}`) }
  }
  const accepted = requests.filter((r) => r.status === 'accepted')
  const incoming = requests.filter((r) => r.status === 'pending' && r.recipient_id === user.id)
  const outgoing = requests.filter((r) => r.status === 'pending' && r.sender_id === user.id)
  return <><div className="page-intro"><span className="eyebrow">YOUR PEOPLE</span><h1>Your crew.</h1><p>Find other GigMate members, build a crew and decide what to see together.</p></div><div className="crew-columns"><section className="panel"><div className="panel-heading"><Users/><div><h2>Your crews</h2><p>Share an invite code to bring your group together.</p></div></div><form className="inline-form" onSubmit={createCrew}><input required minLength={2} maxLength={60} value={crewName} onChange={(e) => setCrewName(e.target.value)} placeholder="Name your new crew"/><button className="button" disabled={busy}><Plus size={16}/> Create</button></form><form className="inline-form" onSubmit={joinCrew}><input required minLength={6} maxLength={12} value={inviteCode} onChange={(e) => setInviteCode(e.target.value.toUpperCase())} placeholder="Enter invite code"/><button className="button button-outline" disabled={busy}>Join crew</button></form><div className="crew-list">{crews.length ? crews.map((crew) => <div className="crew-item" key={crew.id}><div className="crew-avatar"><Users size={18}/></div><div className="crew-item-main"><b>{crew.name}</b><span>{crew.role === 'owner' ? 'Your crew' : 'Member'} · Invite code <strong>{crew.invite_code}</strong></span></div><button className="icon-button" onClick={() => void copyCode(crew)} title="Copy invite code">{inviteCopied === crew.id ? <Check size={16}/> : <Copy size={16}/>}</button></div>) : <p className="muted-copy">No crews yet. Create one or join with a friend's code.</p>}</div></section><section className="panel"><div className="panel-heading"><UserPlus/><div><h2>Find friends</h2><p>Search by username. Blocked accounts are hidden from search.</p></div></div><form className="inline-form" onSubmit={searchFriends}><input value={friendSearch} onChange={(e) => setFriendSearch(e.target.value)} placeholder="Search username"/><button className="button" disabled={friendSearch.trim().length < 2}><Search size={16}/> Find</button></form>{friendResults.map((person) => <div className="person-row" key={person.id}><div className="person-avatar">{person.avatar_path ? <img src={getAvatarUrl(person.avatar_path) ?? ''} alt=""/> : <CircleUserRound/>}</div><div><b>{person.display_name}</b><span>@{person.username}</span></div><div className="person-actions"><button className="button button-small" onClick={() => void sendRequest(person.username)}>Add</button><button className="button button-small button-quiet" onClick={() => void blockMember(person.id, person.display_name)}>Block</button></div></div>)}{incoming.length > 0 && <><h3 className="subheading">Friend requests for you</h3>{incoming.map((r) => <div className="person-row" key={r.id}><div><b>{people[r.sender_id]?.display_name || 'GigMate member'}</b><span>@{people[r.sender_id]?.username || 'member'}</span></div><div className="person-actions"><button className="button button-small" onClick={() => void respond(r.id,true)}>Accept</button><button className="button button-small button-quiet" onClick={() => void respond(r.id,false)}>Decline</button><button className="button button-small button-quiet" onClick={() => void blockMember(r.sender_id, people[r.sender_id]?.display_name || 'this member')}>Block</button></div></div>)}</>}{outgoing.length > 0 && <p className="muted-copy">{outgoing.length} friend request{outgoing.length === 1 ? '' : 's'} waiting for a reply.</p>}{accepted.length > 0 && <><h3 className="subheading">Your friends</h3>{accepted.map((r) => { const personId = r.sender_id === user.id ? r.recipient_id : r.sender_id; const person = people[personId]; return <div className="person-row" key={r.id}><div><b>{person?.display_name || 'GigMate member'}</b><span>@{person?.username || 'member'}</span></div><div className="person-actions"><span className="friend-status"><Check size={13}/> Friends</span><button className="button button-small button-quiet" onClick={() => void blockMember(personId, person?.display_name || 'this member')}>Block</button></div></div> })}</>}{blockedMembers.length > 0 && <><h3 className="subheading">Blocked accounts</h3>{blockedMembers.map((person) => <div className="person-row" key={person.id}><div><b>{person.display_name}</b><span>@{person.username}</span></div><button className="button button-small button-outline" onClick={() => void unblockMember(person.id)}>Unblock</button></div>)}</>}</section></div></>
}
function ModerationPage({ onMessage, onChanged }: { onMessage: (message: string, isError?: boolean) => void; onChanged: () => Promise<void> }) {
  const [pending, setPending] = useState<Gig[]>([])
  const [reports, setReports] = useState<EventReport[]>([])
  const [loading, setLoading] = useState(true)
  const [workingId, setWorkingId] = useState('')
  const loadPending = useCallback(async () => {
    if (!sb) return
    setLoading(true)
    const [eventsResult, reportsResult] = await Promise.all([
      sb.from('events').select('id,title,description,starts_at,is_free,price_from,ticket_url,venue_name,suburb,state,country,status,event_lineup(artist_name,position)').eq('status','pending').order('created_at').limit(100),
      sb.from('event_reports').select('id,event_id,reporter_id,reason,status,created_at,events(title,venue_name,starts_at)').eq('status','open').order('created_at').limit(100),
    ])
    setLoading(false)
    if (eventsResult.error) onMessage(eventsResult.error.message, true)
    else setPending((eventsResult.data ?? []) as Gig[])
    if (reportsResult.error) onMessage(reportsResult.error.message, true)
    else setReports((reportsResult.data ?? []) as EventReport[])
  }, [])
  useEffect(() => { void loadPending() }, [loadPending])
  const review = async (gig: Gig, status: 'approved' | 'rejected') => {
    if (!sb) return
    setWorkingId(gig.id)
    const { data: userData } = await sb.auth.getUser()
    const { error: updateError } = await sb.from('events').update({ status, reviewed_by: userData.user?.id, reviewed_at: new Date().toISOString() }).eq('id', gig.id)
    setWorkingId('')
    if (updateError) onMessage(updateError.message, true)
    else { onMessage(`Gig ${status}.`); await loadPending(); await onChanged() }
  }
  const reviewReport = async (report: EventReport, status: 'reviewed' | 'dismissed') => {
    if (!sb) return
    setWorkingId(report.id)
    const { error: updateError } = await sb.from('event_reports').update({ status }).eq('id', report.id)
    setWorkingId('')
    if (updateError) onMessage(updateError.message, true)
    else { onMessage(status === 'reviewed' ? 'Report marked as reviewed.' : 'Report dismissed.'); await loadPending() }
  }
  return <><div className="page-intro"><span className="eyebrow">COMMUNITY SAFETY</span><h1>Moderation queue.</h1><p>Review gig submissions and reports. Remove or reject inaccurate, misleading or abusive listings and respond to reports promptly.</p></div><section><div className="section-heading"><div><h2>Gig submissions</h2><p>New listings are private until approved by a moderator.</p></div></div>{loading ? <div className="empty-state"><LoaderCircle className="spin"/></div> : !pending.length ? <div className="empty-state"><ShieldCheck size={28}/><h3>No pending gigs.</h3><p>There are no event submissions waiting for approval.</p></div> : <div className="moderation-list">{pending.map((gig) => <article className="moderation-card" key={gig.id}><div><span className="pending-label">PENDING REVIEW</span><h3>{gig.title}</h3><p>{gig.venue_name} · {gig.suburb}, {gig.state}</p><p>{formatDate(gig.starts_at)}</p><p>{gig.description}</p><p className="muted-copy">Line-up: {(gig.event_lineup ?? []).map((item) => item.artist_name).join(' · ') || 'Not supplied'}</p></div><div className="moderation-actions"><button className="button" disabled={workingId === gig.id} onClick={() => void review(gig,'approved')}><Check size={16}/> Approve</button><button className="button button-quiet" disabled={workingId === gig.id} onClick={() => void review(gig,'rejected')}><X size={16}/> Reject</button></div></article>)}</div>}</section><section className="moderation-reports"><div className="section-heading"><div><h2>Community reports</h2><p>Review concerns raised about approved events.</p></div></div>{loading ? <div className="empty-state"><LoaderCircle className="spin"/></div> : !reports.length ? <div className="empty-state"><ShieldCheck size={24}/><h3>No open reports.</h3><p>New event reports will appear here for staff review.</p></div> : <div className="moderation-list">{reports.map((report) => <article className="moderation-card" key={report.id}><div><span className="pending-label">OPEN REPORT</span><h3>{report.events?.title || 'Event report'}</h3><p>{report.events?.venue_name || ''}{report.events?.starts_at ? ` · ${formatDate(report.events.starts_at)}` : ''}</p><p>{report.reason}</p><p className="muted-copy">Submitted {formatDate(report.created_at)}</p></div><div className="moderation-actions"><button className="button" disabled={workingId === report.id} onClick={() => void reviewReport(report,'reviewed')}><Check size={16}/> Mark reviewed</button><button className="button button-quiet" disabled={workingId === report.id} onClick={() => void reviewReport(report,'dismissed')}>Dismiss</button></div></article>)}</div>}</section></>
}
export default App
