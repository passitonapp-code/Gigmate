# Android, iPhone and other distribution routes

## Distribution order

1. Launch and test the HTTPS web application.
2. Make the PWA installable for Android and iPhone home screens.
3. Package the same code with Capacitor after the product has meaningful, reliable app behaviour.
4. Release Android first if that is the device you can test most easily; release iOS when a Mac/Xcode build and Apple review are ready.

## Google Play

- Enrol in Google Play Console using your developer details and complete account verification.
- Generate a signed Android App Bundle (`.aab`) from Android Studio.
- Prepare app name, icon, screenshots, short/full descriptions, privacy policy, support contact, content rating, target audience and Data Safety disclosures. Provide the public, functional account-deletion URL (`/delete-account.html`) in the Play Console Data safety/account-deletion declaration after the production domain is known.
- Complete internal testing, then closed testing.
- For personal developer accounts created after 13 November 2023, Google currently requires at least 12 testers opted into a closed test continuously for 14 days before you can apply for production access.
- Answer the production-access questions and submit for review.

Live concert tickets are physical services consumed outside the app. Google Play's policy says Play Billing must not be used for live-event tickets; use an approved external payment method/provider for those transactions. Digital subscriptions or paid digital features would need a separate policy review.

## Apple App Store

- Enrol in the Apple Developer Program.
- Create an App Store Connect record and register the bundle identifier.
- Before submission, complete the real support/contact information and staff the moderation process. This app accepts user-submitted gig listings, so Apple expects content filtering/moderation, a working report mechanism with timely responses, user blocking and published contact information. The kit includes pending-listing review, event reports, member blocking and an admin moderation queue, but the moderation team, response procedures and support contact must be supplied by the operator.
- Build/sign/archive with Xcode on a Mac and upload for TestFlight testing.
- Prepare screenshots, support URL, privacy-policy URL, age rating, app privacy disclosures and reviewer access/test account.
- Submit the finished app for App Review.

Apple's guidelines require an app to deliver more than a repackaged website. They ask for complete, tested functionality and working backend services at review time. Sales of physical goods/services consumed outside the app, such as concert tickets, use payment methods other than Apple in-app purchase (for example card payment / Apple Pay) under the applicable rule. A ticketing marketplace still needs its own compliant payment, seller and consumer-protection design.

## PWA and native limitations

- PWA: no store review is required, but device/browser support differs. A PWA is not the same as an App Store listing.
- Android native: Android Studio and the SDK are required for a signed `.aab`.
- iOS native: macOS and Xcode are required; an Android phone or Windows-only computer cannot build the final iOS binary.
- Capacitor creates native containers; merely wrapping a thin website is not enough to guarantee Apple acceptance. Native-quality navigation, notifications/deep links, account handling, error states and real utility should be tested.

No store approval is guaranteed. Do not submit while the app contains placeholders, test-only data, nonworking features or unfinished privacy disclosures.
