# GigMate — real app foundation

This is a new, mobile-first GigMate application built to replace the static HTML prototype. It preserves the original dark/pink/purple GigMate identity and the existing **For You**, **Discover**, **Your Crew**, and **Saved** ideas. It adds real authentication, profiles, local gig submissions, artist and venue directories, moderation, friend requests and crew voting, backed by Supabase.

**There are no sample gig records and no decorative action buttons.** The app reads approved records from the connected database. A gig submission is stored as `pending` and is not displayed publicly until a moderator approves it. Save, friend, crew, vote, profile and report actions write to Supabase.

## What's included

- React + TypeScript + Vite web application.
- Supabase email/password authentication and profiles.
- PostgreSQL migration with Row Level Security (RLS), least-privilege table grants and server-validated RPCs.
- Community-submitted gigs, line-ups, new venue/artist records and a moderation queue.
- Account deletion through an authenticated server-side Edge Function, plus a public browser-based deletion form that verifies the account credentials and works without installing the mobile app (never exposes the service-role key to the browser).
- Public approved-event feed, artist directory and venue directory.
- Saved gigs synchronised to the signed-in member's account.
- Friend requests, crew creation/join codes and shared crew votes.
- Member blocking, one-report-per-member/event reporting, and a staff moderation queue for new gigs and open reports.
- Password-reset email flow through Supabase Auth, plus account deletion.
- Secure avatar uploads to the Supabase Storage `avatars` bucket.
- Optional Ticketmaster Discovery API search through a Supabase Edge Function. The API key remains server-side; it is not bundled into the browser.
- PWA manifest, install icons and a conservative app-shell service worker.
- Capacitor configuration for Android and iOS packaging.
- Build workflow for GitHub Actions.

## Important boundaries — read before launch

1. **A Supabase project is required.** Without your project URL/key, the app intentionally shows a setup screen instead of inventing data.
2. **The ticket resale marketplace is not enabled in this build.** There is no Buy or Sell control because live payment processing, seller payouts, ticket validation and ticket transfers require a contracted marketplace provider and approved ticket-transfer arrangements. See `MARKETPLACE-READINESS.md`.
3. **Ticketmaster search is optional.** It only appears after you register for a Ticketmaster API key, deploy the Edge Function, save the key as a Supabase secret and set the frontend feature flag. It supplements local submissions; it will not discover every tiny pub gig.
4. **Bandsintown is not switched on.** Its multi-artist API requires platform approval and the feed is read-only. It must not be treated as a free unrestricted event database.
5. This is a launch foundation, not a guarantee of app-store acceptance. Test the complete backend, moderation, privacy, abuse reporting and mobile behaviour before submitting.
6. A moderator must actively review submissions and reports. The app does not send moderation alerts or provide a staffed support inbox. Supply and publish a real support contact and an operational response process before public release.

## Quick start

Requirements: Node.js 22 or newer, npm, a Supabase account, and (for native builds) Android Studio / Xcode as appropriate.

```bash
npm install
cp .env.example .env.local
```

Open `.env.local` and set:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
VITE_TICKETMASTER_ENABLED=false
```

Use the **publishable** (or legacy anon) key in the browser. Never use a Supabase `service_role` / secret key in `VITE_` variables or client-side files.

Start the app:

```bash
npm run dev
```

Open the local URL printed by Vite.

## Connect the database

1. Create a Supabase project at <https://supabase.com/dashboard>. Choose an Australia region if available and appropriate for your expected users.
2. In the project, open **Project Settings → API** (or **Connect**) and copy the Project URL and publishable key to `.env.local`.
3. Install the Supabase CLI, sign in, and link the project:

   ```bash
   npx supabase login
   npx supabase link --project-ref YOUR_PROJECT_REF
   ```

4. Apply the migration:

   ```bash
   npx supabase db push
   ```

   Or, for a first-time local setup, follow `npx supabase init`, `npx supabase start` and the Supabase local development guide.

5. In Supabase **Authentication → URL Configuration**, set your local Site URL to `http://localhost:5173` while developing. Add your eventual production URL and any preview URLs to the allowed redirect URLs. Configure email confirmation, password-recovery email templates and account-support arrangements before inviting users. The sign-in screen can request a reset email, and the recovery link opens an in-app new-password form.
6. Sign up for your own GigMate account. Then, in **SQL Editor**, replace the email in the commented admin-bootstrap statement at the bottom of the migration with your email and run it once. This gives your account moderation access. Do not expose a public admin sign-up path.
7. Deploy the account-deletion Edge Function (the Profile screen calls this server-side function):

   ```bash
   npx supabase functions deploy delete-account
   ```

8. Build and test:

   ```bash
   npm run typecheck
   npm run build
   ```

## Optional: enable Ticketmaster event search

Ticketmaster's Discovery API can supplement community data with official event listings. It is not a substitute for direct local submissions.

1. Register for a developer account and API key with <https://developer.ticketmaster.com/>.
2. Deploy the server-side function:

   ```bash
   npx supabase functions deploy search-ticketmaster
   ```

3. Store the key as a Supabase Edge Function secret:

   ```bash
   npx supabase secrets set TICKETMASTER_API_KEY=YOUR_KEY
   ```

4. Set `VITE_TICKETMASTER_ENABLED=true` in the frontend hosting environment and redeploy the frontend.

The feature is hidden unless you deliberately turn it on. If the key is absent, the function returns a configuration error; it does not make up results.

## Deploy the website

The recommended simple route is **Vercel** or **Netlify**, connected to this GitHub repository. The original GitHub Pages root-branch setting will not compile this Vite/TypeScript project by itself. Use pull-request preview deployments and fully test the new site before merging into `main`, otherwise the old Pages URL will start serving unbuilt Vite source. Supabase hosts the database and Edge Functions separately.

For Vercel:

1. Create a Vercel account and import `passitonapp-code/Gigmate` (or your fork).
2. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
3. Add `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, and optionally `VITE_TICKETMASTER_ENABLED` as environment variables.
4. Deploy. Add the resulting URL to Supabase Auth's allowed redirect URLs.
5. Test with a brand-new account, confirm the email, edit the profile, submit a test gig, approve it from the moderation account, save it, and test friend/crew flows with two separate accounts.

Do not put API secrets or a Supabase service-role key into Vercel variables prefixed with `VITE_`.

## Put this project into the existing GitHub repository

For phone-based uploading, see `GITHUB-UPLOAD-GUIDE.md`.

1. Download and extract this launch kit.
2. In GitHub, create a new branch such as `feature/real-app-foundation` from `main`.
3. Upload the **contents** of the extracted `GigMate-Launch-Kit` folder into the repository root (not a nested folder containing the whole kit).
4. Replace the old root `index.html` and `README.md`. The old root `manifest.webmanifest`, `service-worker.js` and `icon.svg` are no longer used by Vite; remove them to avoid confusion. The new versions live under `public/`.
5. Commit to the feature branch and open a pull request into `main`. Check the GitHub Actions build result before merging.
6. Connect Vercel/Netlify to the repository as described above.

Keep `.env.local` out of GitHub. `.gitignore` is configured to ignore it.

## Native Android and iOS builds

After the web build works on your production domain:

```bash
npm install
npm run build
npx cap add android
npx cap add ios
npx cap sync
```

Open the Android project with Android Studio (`npx cap open android`) and the iOS project with Xcode on a Mac (`npx cap open ios`). Add platform-specific icons, splash screens, app permissions and deep-link configuration before release. Keep the native platform folders in GitHub after generating them if you want repeatable builds.

Capacitor 8 currently requires Node.js 22 or newer. An iOS build and App Store upload requires macOS and Xcode. A Windows or Android phone alone cannot produce the final iOS binary.

## Before any public launch

- Configure a real production Supabase project, Auth emails and storage.
- Create at least one moderator and verify moderation works.
- Publish Terms of Service, Privacy Policy, Community Guidelines, Contact/Support and takedown/reporting process.
- Add rate limiting/anti-spam controls and monitoring before a large public user base.
- Test two or more accounts on different devices.
- Verify backups, data deletion/account deletion and incident response.
- Do not activate ticket resale until `MARKETPLACE-READINESS.md` is satisfied.

## Privacy, terms and community rules

Draft documents are in `legal/`. The deployed legal pages are `public/privacy.html` and `public/terms.html`; the browser-based account deletion form is built from `delete-account.html` and is published at `/delete-account.html`. They contain explicit placeholders for the operator's legal name, ABN, privacy/support contact, subprocessors and retention schedule. **Do not submit the app to a store or open registration until these are completed and legally reviewed.**
