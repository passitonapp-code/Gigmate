# GigMate build status — honest handover

## Present in this kit

- React + TypeScript + Vite application.
- Supabase email/password authentication and profile setup.
- User profiles, avatar uploads, local gig submissions, pending-review moderation, approved event feed, artist/venue directories, saved gigs, friend requests, crews and shared crew votes.
- Event reporting, member blocking/unblocking, a staff moderation queue for listings and reports, and account deletion Edge Function with a public web deletion-information page.
- Password-reset email initiation and a recovery-link screen using Supabase Auth.
- A separate web account-deletion form at `/delete-account.html`, which verifies the account by signing in through Supabase Auth and invokes the same authenticated deletion function without requiring the mobile app.
- Optional server-side Ticketmaster Discovery API search adapter.
- PWA shell and Capacitor configuration for Android/iOS builds.
- CI workflow, setup instructions, draft policies and marketplace integration plan.

## Deliberately not enabled

- Peer-to-peer resale, Buy/Sell checkout, card collection, seller onboarding, payouts or ticket transfers. These require a payment provider to approve the resale business model and ticketing providers to support the transfer/verification workflow. No such credentials or agreements were supplied.
- Spotify account linking or listening-history access. GigMate's artist/genre directory and community listings do not depend on Spotify.
- Automatic GPS/radius discovery. The current first build filters by the member's manually entered suburb/town and state.
- Dedicated artist/venue/promoter login roles or claimed page management. Artist/venue directory records are generated from reviewed gig submissions.
- Push notifications or a staffed support/moderation operation. The in-app flow can request a password reset and accept the Supabase recovery link, but email delivery/domain settings must be configured and tested.
- Unapproved scraping or automatic importing of private social-media posts.
- Fake events, fake test payments, fake friend actions or demo ticket purchases.

## Validation performed in this environment

- Parsed all seven TypeScript/TSX source files with the globally available TypeScript transpiler (zero syntax errors).
- Ran a limited source type check against temporary local dependency stubs; this is not a substitute for the real TypeScript project build with installed React/Supabase package types.
- Inspected the SQL migration, application configuration and Edge Function source.
- `npm install` timed out while reaching the npm registry in this environment. Dependencies were not installed, no package lock was generated, and the full `npm run typecheck` / `npm run build` production commands could not be run. No claim is made that the first GitHub Actions build will pass.
- The SQL migration has not been applied to a real Supabase project, and no live sign-up/payment/provider transactions have been tested.

## Must be done before a public launch

1. Install dependencies and run `npm run typecheck` and `npm run build`.
2. Apply the migration to a new Supabase project and test all listed flows with at least two accounts.
3. Deploy the `delete-account` Edge Function and test deletion.
4. Review RLS and storage behaviour using anonymous, ordinary-member and moderator accounts.
5. Complete privacy, terms, community rules, contact and support details with qualified legal review.
6. Add anti-abuse controls, monitoring, backups, a published support contact, staffed moderation/report response procedures and incident response before opening registration widely.
7. For marketplace functionality, obtain written payment-provider approval and transfer/verification agreements before any Buy/Sell feature is designed into the user-facing app.
