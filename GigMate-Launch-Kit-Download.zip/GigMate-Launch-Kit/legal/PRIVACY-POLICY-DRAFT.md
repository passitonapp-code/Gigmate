# GigMate Privacy Policy — draft requiring owner details and legal review

**Effective date:** [insert date]  
**Operator:** [insert legal business/entity name, ABN and address]  
**Privacy contact:** [insert monitored privacy contact email]

This draft describes the data flows currently implemented in this codebase. Do not publish it until the operator details are completed, hosting/subprocessor details are checked and Australian privacy counsel has reviewed it.

## Information collected

When a person creates an account, GigMate processes their email address through Supabase Authentication and stores a profile containing a username, display name, optional bio, suburb/state and optional profile image. The service stores gig submissions, event line-ups, saved gigs, friend requests, crew memberships, crew votes, event reports and basic timestamps needed to operate the service.

The current application does not request precise device location, does not connect to Spotify, does not collect payment-card details and does not operate a ticket resale checkout. If any of these features are added, this policy and the relevant consent screens must be updated before release.

## Why information is used

Information is used to create and secure accounts, show member profiles, publish moderated community gig listings, synchronise saved gigs, connect friends, support crew planning, respond to reports, prevent abuse and provide support.

## Public information

Approved event listings, artist/venue directory details and public profile fields may be visible to other signed-in members as described in the app. Profile email addresses are not displayed in the public profile. Do not put private information in a public bio or gig description.

## Service providers

The current architecture uses Supabase for authentication, database hosting, file storage and server-side functions. If the optional Ticketmaster search is enabled, search terms and city/state filters are sent server-side to Ticketmaster to retrieve its event listings. The operator must list the actual hosting provider, email provider, analytics provider and any other subprocessor used in production before publishing this policy.

## Storage and security

Passwords are handled by Supabase Auth and are not stored in GigMate profile tables. Profile pictures are stored in the Supabase `avatars` bucket. The database uses row-level security to restrict member-specific information. These controls reduce risk but do not guarantee that a service is completely secure.

## Retention and account deletion

Members can request permanent account deletion from the Profile screen. The app calls an authenticated server-side function to delete the Supabase Auth account and associated account records. Profile images are removed where possible. Gig submissions and associated artist/venue/event records may be retained in an anonymised form where needed to preserve the public event record, prevent duplicate spam or meet legal obligations. The operator must define a retention schedule and contact process for any records not deleted automatically.

## Children

The operator must decide the minimum account age and age restrictions for events, obtain legal advice and configure the app-store age rating and parental/privacy handling accordingly. Do not launch until this section is completed.

## Access, correction and complaints

For access, correction, privacy questions or complaints, contact [insert privacy contact]. Explain how requests are authenticated and how promptly the operator will respond. Australian Privacy Act obligations depend on the operator and circumstances; obtain legal advice about applicability.

## Changes

This policy may be updated as the service changes. The operator should record the effective date and notify members of material changes.
