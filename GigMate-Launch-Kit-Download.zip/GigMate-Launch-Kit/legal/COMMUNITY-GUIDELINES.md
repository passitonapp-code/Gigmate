# GigMate Community Guidelines — draft

- Share real shows, not rumours or invented events.
- Include the correct date, local start time, venue, suburb, line-up and entry details.
- Do not submit a gig on behalf of an artist or venue in a way that suggests you represent them.
- Do not upload images, logos or ticket evidence you do not have permission to use.
- No harassment, hate speech, threats, doxxing, impersonation, spam or scams.
- Respect age restrictions, venue rules and accessibility information.
- Report incorrect, cancelled, unsafe or misleading listings.
- A “Reviewed” label means a moderator approved the submission; it is not a guarantee that the event cannot later change or that every ticket/link is valid.
- Repeated misuse can result in content removal or account restriction.
