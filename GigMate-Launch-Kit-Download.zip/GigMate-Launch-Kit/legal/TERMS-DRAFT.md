# GigMate Terms of Use — draft requiring owner details and legal review

**Operator:** [insert legal business/entity name and ABN]  
**Contact:** [insert monitored support email]  
**Effective date:** [insert date]

This draft is a starting point, not legal advice. Have an Australian lawyer review it before public use, particularly for user-generated content, consumer guarantees, minors, moderation, ticketing and any future marketplace.

## Using GigMate

GigMate helps people discover live music, publish community gig information, find artists and venues, save events and coordinate with friends. You must provide accurate account details, protect your sign-in credentials and use the service lawfully.

## Community event submissions

You may submit events only when you have a reasonable basis to share the information. You are responsible for the accuracy of dates, times, venue, line-up, age limits, entry price and ticket links. Do not submit false, misleading, duplicated, unlawful, discriminatory or infringing material. A submission is not public until GigMate approves it. GigMate may edit, reject, remove or correct listings and may ask for evidence.

## Artist, venue and other content

You must own or have permission to submit any text, photographs, logos or other content. By submitting content, you grant the operator a non-exclusive, worldwide, royalty-free licence to host, display, format and promote that content in connection with GigMate. You retain ownership. Do not imply that an artist, venue, promoter or ticket provider endorses GigMate unless it has agreed.

## Friends and crews

Use friend requests, invite codes and crew tools respectfully. Do not harass, impersonate, threaten, spam or expose another person's private information. The operator may suspend accounts or remove content where reasonably necessary to protect members or comply with law.

## Third-party links

GigMate may link to event organisers, venues and ticket providers. Those services are operated by third parties and have their own terms, privacy policies, availability, refund and transfer rules. GigMate is not the ticket seller for an official external ticket link.

## No ticket resale checkout in this release

The current release does not offer peer-to-peer ticket buying, selling, payment processing, seller payouts or ticket transfers. Do not send payment to another user through GigMate. Any future marketplace will require separate terms and a separate launch announcement.

## Reporting and suspension

Use the report function to identify inaccurate, unsafe, fraudulent or inappropriate listings. The operator may review reports, remove content, restrict accounts or retain evidence where legally permitted. This does not promise that every event listing is independently verified in every respect.

## Availability and liability

The service is provided subject to applicable Australian Consumer Law and other non-excludable rights. Event details can change; confirm important details with the venue or organiser before travelling. Nothing in these terms excludes rights that cannot legally be excluded.

## Changes and contact

The operator may update these terms. Material changes should be communicated to members. Questions or complaints: [insert monitored support email and postal address].
