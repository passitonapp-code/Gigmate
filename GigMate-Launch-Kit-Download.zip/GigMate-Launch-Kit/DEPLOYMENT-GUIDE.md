# GigMate deployment and launch guide

This guide gives the practical sequence from this folder to a live, installable application.

## 1 — Create the backend

1. Create a Supabase project and choose a nearby Australia region where available.
2. Copy the Project URL and publishable key into `.env.local`.
3. Install Node.js 22+ and run `npm install`.
4. Install the Supabase CLI, run `npx supabase login`, then `npx supabase link --project-ref YOUR_PROJECT_REF`.
5. Run `npx supabase db push` to create the tables, policies, storage bucket, and RPC functions.
6. In Supabase Auth, configure site URL and redirect URLs for localhost and the final web domain.
7. Deploy the account-deletion function used by the Profile page: `npx supabase functions deploy delete-account`. The public deletion instructions will be available at `/delete-account.html` on the website.
8. Sign up for your owner account. Promote only your own account to admin using the commented SQL at the end of the migration.

## 2 — Test the core flows locally

Run `npm run dev` and test:

- Create an account, confirm the email and sign in.
- Update display name, username, bio, location and avatar.
- Submit a real upcoming gig; verify it is pending and not visible to signed-out users.
- As the admin, open Moderation and approve it.
- Sign out and confirm the approved event appears publicly.
- Sign in as another test account and save the event.
- Send and accept a friend request between two test accounts.
- Create a crew, copy its invite code, join from the second account and vote on a gig.
- Report an event and confirm the report is only visible to its reporter and staff.
- Block a test member and confirm their profile, events, line-ups and directory entries are hidden; unblock afterwards.
- Use Forgot your password? and complete the Supabase email recovery flow.

If any of these fail, do not launch. Check Supabase logs and RLS policies rather than disabling security.

## 3 — Add optional external event search

Register with the Ticketmaster Developer Portal. Deploy the `search-ticketmaster` Edge Function. Save `TICKETMASTER_API_KEY` as a Supabase function secret. Only then set `VITE_TICKETMASTER_ENABLED=true` and redeploy the frontend. The feature is intended as a supplement; local bands and small pub shows must be submitted by artists, venues, promoters or fans.

## 4 — Deploy the public website

Use Vercel or Netlify for the Vite frontend. Import the GitHub repository, enable pull-request previews, set the build command to `npm run build`, output folder to `dist`, and add the two Supabase browser values as environment variables. Add preview and production URLs to Supabase Auth redirect URLs. Test the preview branch before merging: the current GitHub Pages root-branch deployment cannot compile Vite source on its own, so don't replace the current live branch until the new host works.

The existing GitHub Pages root-branch setting will not compile this Vite/TypeScript project by itself. GitHub Pages can still be used with a build-and-deploy workflow for `dist`, but Vercel or Netlify is the simpler first deployment. Supabase hosts the database and Edge Functions separately.

## 5 — Make it installable

The web build is a PWA. On Android, visit the HTTPS domain in Chrome and use **Install app** / **Add to Home screen**. On iPhone, visit the domain in Safari and use **Share → Add to Home Screen**. Test login redirects, file uploads and offline behaviour on real devices; only the app shell is cached, not private data or API results.

## 6 — Build store packages with Capacitor

On a computer with Node 22+:

```bash
npm install
npm run build
npx cap add android
npx cap add ios
npx cap sync
```

Android: install Android Studio and the Android SDK; open with `npx cap open android`, set the package, app signing, icon, splash, app links and release build; create a signed Android App Bundle (`.aab`) for Google Play.

iOS: use a Mac with Xcode; open with `npx cap open ios`, set bundle ID, signing team, icons, privacy strings and associated domains; archive and upload through Xcode/Transporter. Configure and test email-confirmation/password-recovery deep links for each native app scheme before release; the web redirect flow alone does not finish native universal/app-link setup.

## 7 — Store release

Google Play: create the Play Console developer account, complete identity and app declarations, upload the `.aab`, fill privacy/data safety/content rating/store listing, run internal then closed testing, and apply for production access. New personal developer accounts created after 13 November 2023 must have at least 12 opted-in testers continuously for 14 days before applying for production access.

Apple: enrol in the Apple Developer Program, create the App Store Connect app record, complete privacy details, age rating, support/privacy URLs and screenshots, upload using Xcode, test in TestFlight, then submit to App Review. Apple requires an app to provide more than a thin web wrapper; demonstrate the useful native/social/community functionality and give reviewers a working demo account if sign-in is required.

There is no guarantee of approval. Store reviewers can reject incomplete apps, nonfunctional backends, placeholder content or thin website wrappers.
